# Project 3 — TinyRocket 全流程自动化：从自然语言指令到 PPA 报告

## 概述

串联 Project 1（RTL 生成）+ Project 2（后端流程），实现从自然语言指令到物理版图的端到端自动化。

```
自然语言指令 → 需求解析 → RTL 生成 → 后端全流程 → PPA 报告 → PPT
```

## 工具架构

| 工具 | 用途 | 环境 |
|------|------|------|
| 工具1: Docker Desktop | 容器管理 | 本地 |
| 工具2: Claude Code CLI | Agent 编排平台 | 本地 |
| 工具3: Chipyard | RTL 生成 | Docker (ictmrc/chipyard-image:1.9.1-ubuntu-22.04) |
| 工具4: sbt + Java | Chisel/Chipyard 编译 | Chipyard Docker |

后端流程使用 ORFS Docker (openroad/orfs:latest)，复用 Project 2。

## 容器说明

### Chipyard Docker (chipyard-agent)
- 镜像: `ictmrc/chipyard-image:1.9.1-ubuntu-22.04`
- 用途: 生成符合 RISC-V 规范的 Rocket Chip Verilog RTL
- 包含: miniforge3 (Python 3.12), 基础构建工具
- 注意: 首次使用需克隆 Chipyard 源码（需要网络访问）

### ORFS Docker (orfs-agent)
- 镜像: `openroad/orfs:latest`
- 用途: 后端全流程（综合→布局规划→放置→CTS→布线→STA）
- 包含: Yosys, OpenROAD, OpenSTA, KLayout

## RTL 生成流程（工具3）

1. **Chipyard 容器初始化**: 克隆 Chipyard 1.9.1 源码
2. **sbt 编译**: `sbt 'project freechips.rocketchip.system' 'runMain chipyard.RocketModule'`
3. **firtool 导出**: `firtool --verilog *.fir`
4. **Verilator 检查**: `verilator --lint-only *.v`

当前使用内置 RTL 生成器作为回退方案（ORFS 容器无 Chipyard 环境时）。

## 后端流程

| 阶段 | 工具 | 验收标准 |
|------|------|----------|
| 综合 | Yosys | 门数 > 0 |
| 布局规划 | OpenROAD | 利用率 50-70% |
| 放置 | OpenROAD | 密度 < 80% |
| 时钟树 | OpenROAD | Skew < 0.5ns |
| 布线 | OpenROAD | DRC = 0 |
| STA | OpenSTA | WNS ≥ 0 |

## 使用方法

```bash
# 检查容器状态
make docker-status

# 完整流程
make run-full DESIGN_NAME=tinyRocket

# 分步运行
make gen-rtl         # RTL 生成
make run-backend     # 后端流程
make gen-ppt         # PPT 生成

# 查看结果
make view-layout     # 版图
make report          # PPA 报告
make status          # 流程状态
```

## 目录结构

```
project3/
├── CLAUDE.md                          # 本文件
├── Makefile                           # 统一入口
├── docker-compose.yml                 # 容器编排
├── orchestrator/                      # 编排脚本
├── scripts/
│   ├── chipyard_gen.py              # RTL 生成
│   ├── backend_flow.py              # 后端流程
│   ├── ppa_report.py               # PPA 报告
│   └── gen_ppt.py                  # PPT 生成
├── design/
│   ├── chipyard/                    # Chipyard 配置
│   ├── rtl/                        # 生成的 RTL
│   └── constraints/                # SDC 约束
├── results/                         # 各阶段结果
├── reports/                         # 报告
├── logs/                            # 日志
├── agent/logs/                     # Agent 日志
└── ppt/                            # PPT 输出
```
