#!/usr/bin/env bash
# MCP Server 安装脚本
# 将 Claude Code 配置指向本项目的 MCP Server

set -e

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CONFIG_FILE="${HOME}/.config/Claude/claude_desktop_config.json"
FALLBACK_CONFIG="${PROJECT_DIR}/mcp_server/.claude_desktop_config.json"

echo "=== TinyRocket MCP Server 安装 ==="
echo "项目目录: $PROJECT_DIR"

# 检测 OS
if [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
    CONFIG_FILE="${APPDATA}/Claude/claude_desktop_config.json"
    echo "[OS] Windows (WSL) — 配置路径: $CONFIG_FILE"
else
    echo "[OS] Linux/macOS — 配置路径: $CONFIG_FILE"
fi

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "[错误] Node.js 未安装，请先安装 Node.js 18+"
    exit 1
fi
echo "[OK] Node.js: $(node --version)"

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "[错误] Python3 未安装"
    exit 1
fi
echo "[OK] Python: $(python3 --version)"

# 安装 npm 依赖（本项目 mcp_server 目录内）
cd "$PROJECT_DIR/mcp_server"
if [ ! -d "node_modules" ]; then
    echo "[安装] npm 依赖..."
    npm install 2>&1 | tail -3
fi

# 构造 MCP 配置
NODE_CMD="node"
if [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
    # WSL 中 Node.js 路径
    NODE_CMD=$(which node 2>/dev/null || echo "node")
fi

SCRIPT_PATH="$PROJECT_DIR/mcp_server/index.js"

CONFIG_JSON=$(cat <<EOF
{
  "mcpServers": {
    "tinyrocket": {
      "command": "$NODE_CMD",
      "args": ["$SCRIPT_PATH"],
      "env": {},
      "description": "TinyRocket 全流程自动化 MCP Server"
    }
  }
}
EOF
)

# 写入配置文件
mkdir -p "$(dirname "$CONFIG_FILE")"

if [ -f "$CONFIG_FILE" ]; then
    echo "[检测] 已有 Claude Code 配置: $CONFIG_FILE"
    echo "[提示] 请手动将 tinyrocket mcpServer 配置添加到 $CONFIG_FILE"
    echo "$CONFIG_JSON" > "$FALLBACK_CONFIG"
    echo "[已保存] 备用配置: $FALLBACK_CONFIG"
else
    echo "$CONFIG_JSON" > "$CONFIG_FILE"
    echo "[已创建] Claude Code MCP 配置: $CONFIG_FILE"
fi

# 测试 MCP Server
echo ""
echo "=== 测试 MCP Server ==="
cd "$PROJECT_DIR"
node mcp_server/index.js --test

echo ""
echo "=== 安装完成 ==="
echo "请重启 Claude Code 以加载 MCP Server"
echo "配置路径: $CONFIG_FILE"
