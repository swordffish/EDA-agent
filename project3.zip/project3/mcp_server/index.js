#!/usr/bin/env node
/**
 * TinyRocket MCP Server Node.js wrapper
 * ====================================
 * Starts Python MCP Server and proxies stdio for JSON-RPC communication.
 * Claude Code MCP client communicates via this process (stdio transport).
 */

import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import * as readline from 'readline';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Start Python MCP Server
const pythonPath = 'python3';
const scriptPath = join(__dirname, 'tinyrocket_server.py');

const pythonProc = spawn(pythonPath, [scriptPath], {
  stdio: ['pipe', 'pipe', 'pipe'],
  env: { ...process.env, PYTHONUNBUFFERED: '1' }
});

let reqId = 1;
const pending = new Map();

// ── CRITICAL FIX: Forward parent stdin → Python stdin ─────────────────
// This is how Claude Code sends MCP requests to us
process.stdin.on('data', (chunk) => {
  pythonProc.stdin.write(chunk);
});

process.stdin.on('end', () => {
  pythonProc.stdin.end();
});

// Forward Python stdout → parent stdout (MCP stdio protocol)
pythonProc.stdout.on('data', (chunk) => {
  process.stdout.write(chunk);
});

// Forward Python stderr → parent stderr (debug output)
pythonProc.stderr.on('data', (chunk) => {
  process.stderr.write(chunk);
});

// Handle process exit
pythonProc.on('exit', (code) => {
  process.exit(code ?? 0);
});

process.on('SIGINT', () => {
  pythonProc.kill('SIGINT');
  process.exit(0);
});

process.on('SIGTERM', () => {
  pythonProc.kill('SIGTERM');
  process.exit(0);
});

// ── Exported RPC interface (for testing) ──────────────────────────────

export function callTool(toolName, args = {}) {
  return new Promise((resolve, reject) => {
    const id = reqId++;
    const msg = {
      jsonrpc: '2.0',
      id,
      method: 'tools/call',
      params: { name: toolName, arguments: args }
    };
    pending.set(id, { resolve, reject });
    pythonProc.stdin.write(JSON.stringify(msg) + '\n');

    // Timeout 5 minutes (backend flow may be long)
    setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        reject(new Error(`Tool ${toolName} timeout after 300s`));
      }
    }, 300000);
  });
}

// Handle MCP responses (from Python process)
const rl = readline.createInterface({
  input: pythonProc.stdout,
  crlfDelay: Infinity,
});

rl.on('line', (line) => {
  if (!line.trim()) return;
  try {
    const resp = JSON.parse(line);
    const id = resp.id;
    if (id && pending.has(id)) {
      const { resolve, reject } = pending.get(id);
      pending.delete(id);
      if (resp.error) {
        reject(new Error(resp.error.message));
      } else {
        resolve(resp.result);
      }
    }
  } catch (e) {
    console.error('[MCP] Parse error:', e.message);
  }
});

export async function listTools() {
  return new Promise((resolve, reject) => {
    const id = reqId++;
    const msg = {
      jsonrpc: '2.0',
      id,
      method: 'tools/list',
      params: {}
    };
    pending.set(id, { resolve, reject });
    pythonProc.stdin.write(JSON.stringify(msg) + '\n');
    setTimeout(() => {
      if (pending.has(id)) { pending.delete(id); reject(new Error('listTools timeout')); }
    }, 10000);
  });
}

export async function initialize() {
  return new Promise((resolve, reject) => {
    const id = reqId++;
    const msg = {
      jsonrpc: '2.0',
      id,
      method: 'initialize',
      params: {
        protocolVersion: '2024-11-05',
        clientInfo: { name: 'claude-code', version: '1.0' },
        capabilities: { tools: {} }
      }
    };
    pending.set(id, { resolve, reject });
    pythonProc.stdin.write(JSON.stringify(msg) + '\n');
    setTimeout(() => {
      if (pending.has(id)) { pending.delete(id); reject(new Error('initialize timeout')); }
    }, 10000);
  });
}

// Command-line test mode
if (process.argv[2] === '--test') {
  (async () => {
    try {
      console.log('[Test] Initializing MCP Server...');
      await initialize();
      console.log('[Test] Listing tools...');
      const tools = await listTools();
      console.log('[Test] Available tools:', tools.tools.map(t => t.name).join(', '));
      console.log('[Test] Testing docker_status...');
      const status = await callTool('docker_status', {});
      console.log('[Test] Docker status:', JSON.stringify(status, null, 2));
      console.log('[Test] Done!');
      pythonProc.kill();
      process.exit(0);
    } catch (e) {
      console.error('[Test] Error:', e.message);
      pythonProc.kill();
      process.exit(1);
    }
  })();
}
