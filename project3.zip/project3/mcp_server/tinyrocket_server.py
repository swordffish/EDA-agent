#!/usr/bin/env python3
"""
TinyRocket MCP Server
=====================
实现 MCP (Model Context Protocol) 标准协议
封装 5 个工具：RTL生成、后端流程、PPA查询、容器状态、错误诊断

MCP 协议：JSON-RPC 2.0 over stdio
- 发送: {"jsonrpc":"2.0","id":N,"method":"tools/list",...}
- 接收: {"jsonrpc":"2.0","id":N,"result":{"tools":[...]}}
"""

import sys
import json
import subprocess
from pathlib import Path
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════════
# 工具定义
# ═══════════════════════════════════════════════════════════════════════════════

TOOLS = [
    {
        "name": "rtl_generate",
        "description": "使用 Chipyard 框架生成 tinyRocket Verilog RTL\n"
                       "输入: design_name (设计名), instruction (自然语言指令)\n"
                       "输出: RTL 文件路径列表、需求规格文档路径",
        "inputSchema": {
            "type": "object",
            "properties": {
                "design_name": {
                    "type": "string",
                    "description": "设计名称，默认 tinyRocket",
                    "default": "tinyRocket"
                },
                "instruction": {
                    "type": "string",
                    "description": "自然语言设计指令",
                    "default": "请生成一个 tinyRocket 处理器"
                }
            }
        }
    },
    {
        "name": "backend_flow_run",
        "description": "运行 OpenROAD 后端全流程（综合→布局→放置→CTS→布线→STA）\n"
                       "输入: design_name (设计名), use_builtin (是否用内置RTL)\n"
                       "输出: 各阶段状态、WNS、门数、DRC违例数",
        "inputSchema": {
            "type": "object",
            "properties": {
                "design_name": {
                    "type": "string",
                    "description": "设计名称",
                    "default": "tinyRocket"
                },
                "use_builtin": {
                    "type": "boolean",
                    "description": "使用 ORFS 内置 RTL（跳过 Chipyard 生成）",
                    "default": True
                }
            }
        }
    },
    {
        "name": "ppa_query",
        "description": "查询当前 PPA 指标\n"
                       "输入: stage (synthesis/floorplan/placement/cts/routing/sta)\n"
                       "输出: 面积(m²)、功耗(W)、频率(MHz)、WNS(ns)、DRC违例数",
        "inputSchema": {
            "type": "object",
            "properties": {
                "stage": {
                    "type": "string",
                    "description": "流程阶段: synthesis|floorplan|placement|cts|routing|sta 或 all",
                    "default": "all"
                },
                "design_name": {
                    "type": "string",
                    "description": "设计名称",
                    "default": "tinyRocket"
                }
            }
        }
    },
    {
        "name": "docker_status",
        "description": "查询 Docker 容器和工具链状态\n"
                       "输出: 容器运行状态、镜像版本、关键工具可用性",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "error_diagnose",
        "description": "诊断后端流程错误并给出修复建议\n"
                       "输入: log_content (错误日志内容)\n"
                       "输出: 错误类型、原因分析、修复策略",
        "inputSchema": {
            "type": "object",
            "properties": {
                "stage": {
                    "type": "string",
                    "description": "出错的流程阶段"
                },
                "error_log": {
                    "type": "string",
                    "description": "错误日志内容（可从 results/logs/*.log 读取）"
                }
            },
            "required": ["stage", "error_log"]
        }
    }
]


# ═══════════════════════════════════════════════════════════════════════════════
# MCP 协议处理器
# ═══════════════════════════════════════════════════════════════════════════════

def read_message():
    """从 stdin 读取一个 JSON-RPC 消息"""
    try:
        line = sys.stdin.readline()
        if not line:
            sys.exit(0)
        msg = json.loads(line.strip())
        return msg
    except (json.JSONDecodeError, EOFError):
        sys.exit(0)


def send_response(req_id, result):
    """发送 JSON-RPC 响应"""
    resp = {"jsonrpc": "2.0", "id": req_id, "result": result}
    print(json.dumps(resp), flush=True)


def send_error(req_id, code, message):
    """发送 JSON-RPC 错误"""
    resp = {"jsonrpc": "2.0", "id": req_id,
            "error": {"code": code, "message": message}}
    print(json.dumps(resp), flush=True)


def send_notification(method, params):
    """发送 JSON-RPC 通知（无 id）"""
    msg = {"jsonrpc": "2.0", "method": method, "params": params}
    print(json.dumps(msg), flush=True)


# ═══════════════════════════════════════════════════════════════════════════════
# 工具执行函数
# ═══════════════════════════════════════════════════════════════════════════════

def run_script(script: str, args: list) -> tuple:
    proj = Path(__file__).parent.parent.resolve()
    cmd = [sys.executable, str(proj / "scripts" / script)] + args
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    return r.returncode, r.stdout, r.stderr


def docker_exec(container: str, cmd: list) -> tuple:
    full = ["docker", "exec", container] + cmd
    r = subprocess.run(full, capture_output=True, text=True, timeout=60)
    return r.returncode == 0, r.stdout, r.stderr


def tool_rtl_generate(args: dict) -> dict:
    design = args.get("design_name", "tinyRocket")
    instr  = args.get("instruction", "请生成一个 tinyRocket 处理器")
    ret, out, err = run_script("chipyard_gen.py",
                                ["--design", design, "--instruction", instr])
    proj = Path(__file__).parent.parent.resolve()
    rtl_dir = proj / "design" / "rtl"
    rtl_files = list(rtl_dir.glob("*.v"))
    spec_file = proj / "agent" / "logs" / "requirement_spec.md"
    return {
        "status": "success" if ret == 0 else "failed",
        "rtl_files": [str(f.name) for f in rtl_files],
        "rtl_count": len(rtl_files),
        "spec_exists": spec_file.exists(),
        "stdout": out[-1000:],
        "stderr": err[-500:] if err else None,
    }


def tool_backend_flow(args: dict) -> dict:
    design = args.get("design_name", "tinyRocket")
    builtin = ["--use-builtin"] if args.get("use_builtin", True) else []
    ret, out, err = run_script("backend_flow.py",
                                ["--design", design] + builtin)
    # 读取流程状态
    proj = Path(__file__).parent.parent.resolve()
    state_file = proj / "results" / "flow_state.json"
    state = {}
    if state_file.exists():
        state = json.loads(state_file.read_text())
    return {
        "status": "success" if ret == 0 else "failed",
        "flow_state": state,
        "stdout": out[-1000:],
        "stderr": err[-500:] if err else None,
    }


def tool_ppa_query(args: dict) -> dict:
    stage = args.get("stage", "all")
    design = args.get("design_name", "tinyRocket")
    proj = Path(__file__).parent.parent.resolve()
    results_dir = proj / "results"

    if stage == "all":
        stages = ["synthesis", "floorplan", "placement", "cts", "routing", "sta"]
    else:
        stages = [stage]

    data = {}
    for s in stages:
        f = results_dir / s / f"{design}_{s}_result.json"
        if f.exists():
            d = json.loads(f.read_text())
            data[s] = {
                "gate_count": d.get("gate_count"),
                "area_um2": d.get("area_um2"),
                "freq_mhz": d.get("freq_mhz"),
                "wns_ns": d.get("wns_ns"),
                "drc_violations": d.get("drc_violations"),
                "total_power_mw": d.get("total_power_mw"),
                "status": d.get("status"),
            }
        else:
            data[s] = {"status": "not_run"}

    return {"stages": data}


def tool_docker_status() -> dict:
    ret1, out1, _ = docker_exec("chipyard-agent", ["echo", "OK"])
    ret2, out2, _ = docker_exec("orfs-agent",     ["echo", "OK"])

    _, cy_ver, _ = docker_exec("chipyard-agent",
                               ["bash", "-c", "cat /etc/os-release | head -1"])
    _, or_ver, _ = docker_exec("orfs-agent",
                               ["bash", "-c", "cat /etc/os-release | head -1"])
    _, openroad_ver, _ = docker_exec("orfs-agent",
                                     ["bash", "-c", "openroad -exit 'puts [openroad::get_db VERSION]'"])
    _, rtl_ver, _ = docker_exec("chipyard-agent",
                                ["bash", "-c", "source /root/miniforge3/etc/profile.d/conda.sh && conda activate /workspace/chipyard/.conda-env && riscv64-unknown-elf-gcc --version 2>/dev/null | head -1 || echo 'not_found'"])

    return {
        "chipyard_agent": {
            "running": ret1,
            "os": cy_ver.strip(),
            "riscvgcc": rtl_ver.strip()[:40],
        },
        "orfs_agent": {
            "running": ret2,
            "os": or_ver.strip(),
            "openroad_version": openroad_ver.strip(),
        }
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 错误诊断专家系统
# ═══════════════════════════════════════════════════════════════════════════════

class ErrorDiagnoser:
    """错误诊断专家系统 — 分析日志，判断错误类型，给出针对性修复策略"""

    def __init__(self):
        self.rules = [
            {
                "type": "timing_violation_setup",
                "keywords": ["setup violation", "WNS", "TNS", "negative slack",
                             "slack < 0", "timing violation", "max_delay"],
                "stage": ["sta", "synthesis", "placement"],
                "priority": 1,
            },
            {
                "type": "timing_violation_hold",
                "keywords": ["hold violation", "hold slack", "min_delay"],
                "stage": ["cts", "routing", "sta"],
                "priority": 2,
            },
            {
                "type": "congestion",
                "keywords": ["congestion", "overflow", "routingCongestion",
                             "pin overflow", "grid overflow"],
                "stage": ["placement", "cts", "routing"],
                "priority": 1,
            },
            {
                "type": "drc_violation",
                "keywords": ["drc", "DRC", "short", "open", "spacing",
                             "antenna", "notch", "width", "area"],
                "stage": ["routing"],
                "priority": 1,
            },
            {
                "type": "lvs_mismatch",
                "keywords": ["lvs", "LVS", "mismatch", "connectivity error",
                             "net count", "pin count"],
                "stage": ["routing", "finish"],
                "priority": 2,
            },
            {
                "type": "clock_skew_high",
                "keywords": ["clock skew", "skew", "CTS", "clock tree"],
                "stage": ["cts"],
                "priority": 2,
            },
            {
                "type": "memory_exceeded",
                "keywords": ["out of memory", "OOM", "killed", "cannot allocate",
                             "malloc failed", "memory limit"],
                "stage": ["synthesis", "placement", "routing"],
                "priority": 1,
            },
            {
                "type": "synthesis_error",
                "keywords": ["error:", "Error:", "ERROR:", "SyntaxError",
                             "verilog syntax", "module not found", "undefined"],
                "stage": ["synthesis"],
                "priority": 1,
            },
            {
                "type": "floating_nets",
                "keywords": ["floating", "no driver", "undriven", "floating nets"],
                "stage": ["synthesis", "floorplan"],
                "priority": 2,
            },
            {
                "type": "missing_sdc",
                "keywords": ["SDC", "constraint", "no clock", "clock not found"],
                "stage": ["synthesis", "sta"],
                "priority": 2,
            },
        ]

        self.strategies = {
            "timing_violation_setup": [
                ("分析", "检查 WNS/TNS 数值，确定违例路径数量和严重程度"),
                ("策略1", "增加 CELL_PAD_IN_SITES_GLOBAL_PLACEMENT=1-2（减少耦合）"),
                ("策略2", "提高 SETUP_SLACK_MARGIN 0.05-0.2ns（保守策略）"),
                ("策略3", "降低目标频率 5-10%（增加 period）"),
                ("策略4", "增加 CORE_UTILIZATION 降低拥塞（减少绕线长度）"),
                ("策略5", "检查关键路径是否有时序不合理的多级组合逻辑"),
                ("不推荐", "盲目重试 — 不定位根因则重试无意义"),
            ],
            "timing_violation_hold": [
                ("分析", "检查 hold slack 数值，正常应 > 0.1ns"),
                ("策略1", "检查时钟树质量 — CTS 后立即检查 skew"),
                ("策略2", "增加 hold buffer（hold fix）"),
                ("策略3", "调整 CTS 参数，降低 skew"),
            ],
            "congestion": [
                ("分析", "检查 congestion_peak > 0.5 的区域位置"),
                ("策略1", "降低 CORE_UTILIZATION 5-10%（减小布局密度）"),
                ("策略2", "增加 CORE_ASPECT_RATIO 至 1.2-1.5（改变形状）"),
                ("策略3", "提高 CELL_PAD_IN_SITES 减少局部密度"),
                ("策略4", "手动放置大型 SRAM 宏单元（macro placement）"),
                ("策略5", "使用 congestion_driven placement"),
            ],
            "drc_violation": [
                ("分析", "统计 DRC 违例数量和类型（spacing/width/antenna）"),
                ("策略1", "spacing 违例 → 调整金属层间距约束"),
                ("策略2", "antenna 违例 → 增加天线二极管保护"),
                ("策略3", "降低 PLACE_DENSITY 减少局部密度"),
                ("策略4", "重新运行 detail_route（更宽松参数）"),
            ],
            "lvs_mismatch": [
                ("分析", "对比 synthesis 前后的门数/引脚数"),
                ("策略1", "检查是否有未连接的模块端口"),
                ("策略2", "确认 .lib 和 .v 的 cell 定义一致"),
                ("策略3", "检查 SRAM 宏单元是否正确定义 LEF/DEF"),
            ],
            "clock_skew_high": [
                ("分析", "检查 skew 值 > 0.3ns 需关注"),
                ("策略1", "降低 CTS_BUF_DISTANCE（增加缓冲器密度）"),
                ("策略2", "使用 clock inverter 减少延迟"),
                ("策略3", "手动约束时钟网络的 max_fanout"),
            ],
            "memory_exceeded": [
                ("分析", "统计门数规模 — >1M 门需注意"),
                ("策略1", "使用 hierarchical synthesis（分模块综合）"),
                ("策略2", "减少 max_threads 或增加 Docker 内存限制"),
                ("策略3", "先综合子模块，再 top-level"),
            ],
            "synthesis_error": [
                ("分析", "确认错误位置（文件名:行号）"),
                ("策略1", "SyntaxError → 检查 Verilog 语法（用 verilator --lint）"),
                ("策略2", "Module not found → 检查 include 路径和 module 定义"),
                ("策略3", "undefined → 检查宏定义和条件编译"),
            ],
            "floating_nets": [
                ("分析", "确认 floating net 的数量和位置"),
                ("策略1", "为未驱动信号添加 tie-off 逻辑"),
                ("策略2", "检查测试平台 TB 的端口连接"),
            ],
            "missing_sdc": [
                ("分析", "确认 clock port 名称与 RTL 一致"),
                ("策略1", "检查 SDC 中 create_clock 的 port 名称"),
                ("策略2", "确认 SDC 路径与 DESIGN_HOME 一致"),
            ],
        }

    def diagnose(self, stage: str, log: str) -> dict:
        log_lower = log.lower()
        matched = []

        for rule in self.rules:
            # 阶段匹配
            if stage and stage.lower() not in [s.lower() for s in rule["stage"]]:
                continue
            # 关键词匹配
            hits = [kw for kw in rule["keywords"] if kw.lower() in log_lower]
            if hits:
                matched.append((rule["priority"], rule["type"], hits))

        if not matched:
            return {
                "diagnosis": "unknown",
                "confidence": "low",
                "stage": stage,
                "reason": "未识别到已知错误模式，建议人工介入",
                "recommendation": [
                    ("步骤1", "查看完整错误日志：results/logs/[stage].log"),
                    ("步骤2", "在 ORFS 容器中手动运行：make run_[stage] 查看详细输出"),
                    ("步骤3", "检查 RTL 质量和 SDC 约束文件是否正确"),
                ],
            }

        # 按优先级排序，取最高优先级
        matched.sort(key=lambda x: x[0])
        primary = matched[0][1]
        all_types = [m[1] for m in matched]

        strategies = self.strategies.get(primary, [])

        return {
            "diagnosis": primary,
            "confidence": "high" if len(matched) >= 2 else "medium",
            "matched_types": all_types,
            "matched_keywords": matched[0][2],
            "stage": stage,
            "reason": f"在 [{stage}] 阶段检测到 {primary}，关键词: {matched[0][2]}",
            "recommendation": strategies,
        }


def tool_error_diagnose(args: dict) -> dict:
    diagnoser = ErrorDiagnoser()
    return diagnoser.diagnose(args.get("stage", ""), args.get("error_log", ""))


# ═══════════════════════════════════════════════════════════════════════════════
# 工具分发器
# ═══════════════════════════════════════════════════════════════════════════════

def handle_initialize(params: dict) -> dict:
    return {
        "protocolVersion": "2024-11-05",
        "serverInfo": {
            "name": "tinyrocket-mcp-server",
            "version": "1.0.0"
        },
        "capabilities": {
            "tools": {},
            "resources": {}
        },
        "instructions": "TinyRocket 全流程自动化 MCP Server — 封装 RTL 生成、后端流程、PPA 查询、容器状态、错误诊断 5 个工具"
    }


def handle_tools_list() -> dict:
    return {"tools": TOOLS}


def handle_tools_call(name: str, args: dict) -> dict:
    handlers = {
        "rtl_generate":    tool_rtl_generate,
        "backend_flow_run": tool_backend_flow,
        "ppa_query":        tool_ppa_query,
        "docker_status":    lambda _: tool_docker_status(),
        "error_diagnose":  tool_error_diagnose,
    }
    fn = handlers.get(name)
    if not fn:
        raise ValueError(f"Unknown tool: {name}")
    result = fn(args)
    # 统一包装为 content array（MCP 标准格式）
    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result, indent=2, ensure_ascii=False)
            }
        ]
    }


def handle_request(msg: dict):
    method = msg.get("method", "")
    req_id = msg.get("id")
    params = msg.get("params", {})

    try:
        if method == "initialize":
            result = handle_initialize(params)
            send_response(req_id, result)

        elif method == "notifications/initialized":
            pass  # 客户端通知，无需回复

        elif method == "tools/list":
            result = handle_tools_list()
            send_response(req_id, result)

        elif method == "tools/call":
            tool_name = params.get("name", "")
            tool_args = params.get("arguments", {})
            result = handle_tools_call(tool_name, tool_args)
            send_response(req_id, result)

        elif method == "ping":
            send_response(req_id, {})

        else:
            send_error(req_id, -32601, f"Method not found: {method}")

    except Exception as e:
        send_error(req_id, -32603, f"Internal error: {str(e)}")


# ═══════════════════════════════════════════════════════════════════════════════
# 主循环
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    # 发送服务器问候
    send_notification("server_ready", {})

    while True:
        msg = read_message()
        if msg is None:
            break
        handle_request(msg)


if __name__ == "__main__":
    main()
