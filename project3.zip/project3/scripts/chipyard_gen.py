#!/usr/bin/env python3
"""
TinyRocket RTL 生成脚本
策略：
1. 优先：复制 ORFS 内置 tinyRocket RTL（已验证可用）
2. 回退：使用项目内置 RTL 生成器
3. 文档：记录完整 Chipyard 框架使用流程
"""

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from datetime import datetime

SCRIPT_DIR = Path(__file__).parent.resolve()
PROJECT_DIR = SCRIPT_DIR.parent.resolve()
RTL_DIR = PROJECT_DIR / "design" / "rtl"
LOGS_DIR = PROJECT_DIR / "logs"
AGENT_LOGS = PROJECT_DIR / "agent" / "logs"
WORKSPACE_HOST = PROJECT_DIR / "design"

AGENT_LOGS.mkdir(parents=True, exist_ok=True)
RTL_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

ORFS_CONTAINER = "orfs-agent"
CHIPYARD_CONTAINER = "chipyard-agent"
ORFS_RTL_SOURCE = "/OpenROAD-flow-scripts/flow/designs/src/tinyRocket"
ORFS_WORKSPACE = "/workspace"

DEFAULT_CONFIG = {
    "design_name": "tinyRocket",
    "isa": "RV64GC",
    "num_cores": 1,
    "l1d_cache_kb": 16,
    "l1i_cache_kb": 16,
    "l2_cache_kb": 512,
    "freq_mhz": 833,
    "config_name": "TinyConfig",
    "module_name": "RocketTile",
}

# ═══════════════════════════════════════════════════════════════════════════════
# Docker 工具函数
# ═══════════════════════════════════════════════════════════════════════════════

def docker_cp(src: Path, container: str, dest: str):
    subprocess.run(["docker", "cp", str(src), f"{container}:{dest}"], check=True)


def docker_exec(container: str, cmd: list, timeout: int = 30) -> tuple:
    full = ["docker", "exec", container] + cmd
    try:
        r = subprocess.run(full, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return False, "", "timeout"


# ═══════════════════════════════════════════════════════════════════════════════
# 需求解析
# ═══════════════════════════════════════════════════════════════════════════════

def parse_instruction(instruction: str) -> dict:
    cfg = DEFAULT_CONFIG.copy()
    inst_lower = instruction.lower()
    import re
    if any(k in instruction for k in ["双核", "dual", "2核"]):
        cfg["num_cores"] = 2
    elif any(k in instruction for k in ["四核", "quad", "4核"]):
        cfg["num_cores"] = 4
    l1 = re.search(r"l1.*?(\d+)\s*[kmg]b?", inst_lower)
    if l1:
        sz = int(l1.group(1))
        cfg["l1d_cache_kb"] = sz
        cfg["l1i_cache_kb"] = sz
    l2 = re.search(r"l2.*?(\d+)\s*[kmg]b?", inst_lower)
    if l2:
        cfg["l2_cache_kb"] = int(l2.group(1))
    freq = re.search(r"(\d+)\s*mhz", inst_lower)
    if freq:
        cfg["freq_mhz"] = int(freq.group(1))
    if "rv32" in inst_lower:
        cfg["isa"] = "RV32GC"
    return cfg


def generate_requirement_spec(cfg: dict, instruction: str) -> str:
    return f"""# TinyRocket 需求规格文档
Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 原始指令
{instruction}

## 解析后的配置

| 参数 | 值 |
|------|-----|
| 设计名称 | {cfg['design_name']} |
| ISA | {cfg['isa']} |
| 核数 | {cfg['num_cores']} |
| L1 D/I Cache | {cfg['l1d_cache_kb']} KB |
| L2 Cache | {cfg['l2_cache_kb']} KB |
| 目标频率 | {cfg['freq_mhz']} MHz |
| 模块名 | {cfg['module_name']} |

## 工具链

| 阶段 | 容器 | 工具 |
|------|------|------|
| RTL 生成 | Chipyard (ictmrc/chipyard-image) | sbt, firtool |
| 后端流程 | ORFS (openroad/orfs:latest) | Yosys, OpenROAD, OpenSTA |

## 验收标准
- [ ] RTL 成功生成，无语法错误
- [ ] 综合成功，无时序违例（目标 {cfg['freq_mhz']} MHz）
- [ ] 布线完成，DRC = 0
- [ ] PPA 报告生成完整
"""


# ═══════════════════════════════════════════════════════════════════════════════
# RTL 生成策略
# ═══════════════════════════════════════════════════════════════════════════════

def copy_orfs_rtl(cfg: dict) -> list[Path]:
    """从 ORFS 容器复制预生成的 tinyRocket RTL"""
    print("  [RTL] 从 ORFS 容器复制 tinyRocket RTL...")
    ok, stdout, _ = docker_exec(ORFS_CONTAINER, ["ls", ORFS_RTL_SOURCE])
    if not ok:
        print("  [错误] ORFS RTL 源目录不存在")
        return []

    # 从容器列出所有 .v 文件再逐一复制（跳过 Chisel 生成的 SoC 顶层模块）
    # TinyConfig.v / freechips.rocketchip.system.TinyConfig.v 是完整的 Rocket Chip SoC，
    # 与自包含的 fallback tinyRocket_* 文件模块名冲突
    skip_patterns = ["TinyConfig", "freechips.rocketchip", "freechips.rocketchip.system"]
    ok, file_list_out, _ = docker_exec(ORFS_CONTAINER, [
        "bash", "-c", f"ls {ORFS_RTL_SOURCE}/*.v 2>/dev/null | xargs -n1 basename"
    ])
    if not ok or not file_list_out.strip():
        print("  [错误] 未找到 RTL 文件")
        return []

    output_files = []
    for fname in file_list_out.strip().split("\n"):
        fname = fname.strip()
        if not fname or any(p in fname for p in skip_patterns):
            continue
        dest = RTL_DIR / fname
        subprocess.run([
            "docker", "cp", f"orfs-agent:{ORFS_RTL_SOURCE}/{fname}", str(dest)
        ], check=True)
        output_files.append(dest)
        sz = dest.stat().st_size // 1024
        print(f"    {fname} ({sz}KB)")

    if not output_files:
        print("  [错误] RTL 文件复制失败")
        return []
    return output_files


def generate_fallback_rtl(cfg: dict) -> list[Path]:
    """生成占位 RTL"""
    design = cfg["design_name"]
    modules = [
        (f"{design}_top", _gen_top(cfg)),
        (f"{design}_core", _gen_core(cfg)),
        (f"{design}_frontend", _gen_frontend(cfg)),
        (f"{design}_icache", _gen_icache(cfg)),
        (f"{design}_dcache", _gen_dcache(cfg)),
        (f"{design}_exe_units", _gen_exe_units(cfg)),
        (f"{design}_regfile", _gen_regfile(cfg)),
        (f"{design}_hazard", _gen_hazard(cfg)),
        (f"{design}_tilelink", _gen_tilelink(cfg)),
        ("sram_macros", _gen_sram_macros()),   # Yosys 综合所需的 SRAM 黑盒
    ]
    files = []
    for name, content in modules:
        path = RTL_DIR / f"{name}.v"
        path.write_text(content)
        files.append(path)
        print(f"  [生成] {name}.v")
    return files


def generate_sdc(cfg: dict) -> str:
    period = round(1000.0 / cfg["freq_mhz"], 3)
    top = f"{cfg['design_name']}_top"
    return f"""current_design {top}
create_clock -name clock -period {period} [get_ports {{clock}}]
set_input_delay [expr {period} * 0.2] -clock clock [all_inputs]
set_output_delay [expr {period} * 0.2] -clock clock [all_outputs]
set_clock_uncertainty 0.05 [get_clocks clock]
set_max_capacitance 0.5 [current_design]
set_max_transition 0.2 [current_design]
set_false_path -from [get_ports reset] -to [get_clocks clock]
"""


# ═══════════════════════════════════════════════════════════════════════════════
# Chipyard 容器状态检查
# ═══════════════════════════════════════════════════════════════════════════════

def check_chipyard_status() -> dict:
    """检查 Chipyard 容器状态"""
    running = subprocess.run(
        ["docker", "ps", "--format", "{{.Names}}"],
        capture_output=True, text=True
    ).stdout
    has_container = CHIPYARD_CONTAINER in running

    status = {
        "container_running": has_container,
        "chipyard_source": False,
        "java_available": False,
        "sbt_available": False,
        "firtool_available": False,
    }

    if has_container:
        ok, out, _ = docker_exec(CHIPYARD_CONTAINER, ["ls", "/workspace/chipyard/build.sbt"])
        status["chipyard_source"] = ok and "build.sbt" in out
        ok, out, _ = docker_exec(CHIPYARD_CONTAINER,
            ["/root/miniforge3/bin/conda", "list"])
        status["java_available"] = ok and "openjdk" in out.lower()

    return status


# ═══════════════════════════════════════════════════════════════════════════════
# RTL 模板
# ═══════════════════════════════════════════════════════════════════════════════

def _gen_top(cfg: dict) -> str:
    n = cfg["num_cores"]
    return f'''// tinyRocket top module
// ISA: {cfg['isa']} | Cores: {n} | Freq: {cfg['freq_mhz']} MHz
module {cfg['design_name']}_top (
    input  wire        clock, reset,
    input  wire [31:0] mem_req_addr,
    output wire [63:0] mem_resp_data,
    output reg         mem_resp_valid
);
    localparam N_CORES = {n};
    wire [31:0]      mem_addr   [0:N_CORES-1];
    wire [63:0]      mem_wdata  [0:N_CORES-1];
    wire              mem_valid  [0:N_CORES-1];
    wire              mem_ready  [0:N_CORES-1];
    wire [63:0]      mem_rdata  [0:N_CORES-1];
    wire              mem_rvalid [0:N_CORES-1];
    genvar i;
    generate for (i=0; i<N_CORES; i=i+1) begin : gen_core
        {cfg['design_name']}_core #(.CORE_ID(i), .ISA("{cfg['isa']}")) c (
            .clock(clock), .reset(reset),
            .mem_addr(mem_addr[i]), .mem_wdata(mem_wdata[i]),
            .mem_valid(mem_valid[i]), .mem_ready(mem_ready[i]),
            .mem_rdata(mem_rdata[i]), .mem_rvalid(mem_rvalid[i])
        );
    end endgenerate
    {cfg['design_name']}_tilelink #(.N_CORES(N_CORES)) tl (
        .clock(clock), .reset(reset),
        .core_addr(mem_addr[0]), .core_valid(mem_valid[0]),
        .core_ready(mem_ready[0]), .core_rdata(mem_rdata[0]),
        .core_rvalid(mem_rvalid[0]),
        .mem_req_addr(mem_req_addr), .mem_resp_data(mem_resp_data),
        .mem_resp_valid(mem_resp_valid)
    );
endmodule
'''


def _gen_core(cfg: dict) -> str:
    return f'''// Rocket Core
module {cfg['design_name']}_core #(
    parameter CORE_ID=0, parameter ISA="RV64GC"
) (
    input  wire        clock, reset,
    output wire [31:0] mem_addr,
    output wire [63:0] mem_wdata,
    output wire        mem_valid, input wire mem_ready,
    input  wire [63:0] mem_rdata, input wire mem_rvalid
);
    reg [31:0] pc = 32'h8000_0000;
    wire [31:0] inst;
    reg         if_valid;
    {cfg['design_name']}_frontend #(.CORE_ID(CORE_ID)) fe (
        .clock(clock), .reset(reset), .pc(pc),
        .inst(inst), .if_valid(if_valid),
        .mem_addr(mem_addr), .mem_valid(mem_valid),
        .mem_ready(mem_ready), .mem_rdata(mem_rdata)
    );
    {cfg['design_name']}_regfile #(.ISA(ISA)) rf (
        .clock(clock), .reset(reset),
        .rs1(inst[19:15]), .rs2(inst[24:20]), .rd(inst[11:7]),
        .we(if_valid), .wdata(64'd0), .rdata1(), .rdata2()
    );
    {cfg['design_name']}_exe_units #(.ISA(ISA)) exe (
        .clock(clock), .reset(reset), .inst(inst),
        .rs1_data(64'd0), .rs2_data(64'd0), .result()
    );
    always @(posedge clock) if (!reset && if_valid) pc <= pc + 4;
endmodule
'''


def _gen_frontend(cfg: dict) -> str:
    return f'''// Frontend
module {cfg['design_name']}_frontend #(
    parameter CORE_ID=0
) (
    input  wire        clock, reset,
    input  wire [31:0] pc,
    output reg  [31:0] inst, output reg if_valid,
    output wire [31:0] mem_addr, output reg mem_valid, input mem_ready,
    input  wire [63:0] mem_rdata
);
    reg [31:0] inst_r = 32'h13;  // Default: ADDI x0, x0, 0 (NOP)
    {cfg['design_name']}_icache #(.SIZE_KB({cfg['l1i_cache_kb']})) icache (
        .clock(clock), .reset(reset),
        .addr({{pc[31:9], 9'd0}}),
        .req_valid(1'b1),
        .line_out({{32'd0, inst_r}}),
        .line_valid(if_valid),
        .mem_addr(mem_addr), .mem_valid(mem_valid),
        .mem_ready(mem_ready), .mem_rdata(mem_rdata)
    );
    always @(posedge clock) begin
        if (!reset) inst <= inst_r;
    end
endmodule
'''


def _gen_icache(cfg: dict) -> str:
    sz = cfg["l1i_cache_kb"]
    sets = max(16, sz // 2)
    return f'''// ICache {sz}KB
module {cfg['design_name']}_icache #(
    parameter SIZE_KB=16
) (
    input  wire        clock, reset,
    input  wire [31:0] addr,
    input  wire        req_valid,
    output reg  [63:0] line_out, output reg line_valid,
    output wire [31:0] mem_addr, output reg mem_valid, input mem_ready,
    input  wire [63:0] mem_rdata
);
    localparam SETS = {sets};
    reg [31:9] tags [0:SETS-1];
    reg        valids [0:SETS-1];
    reg [63:0] data [0:SETS-1];
    wire [$clog2(SETS)-1:0] idx = addr[8+$clog2(SETS)-1:9];
    wire hit = valids[idx] && (tags[idx]==addr[31:9]);
    always @(posedge clock) begin
        if (reset) begin line_valid<=0; mem_valid<=0; end
        else if (req_valid) begin
            if (hit) begin line_out<=data[idx]; line_valid<=1; end
            else begin mem_valid<=1;
                if (mem_ready) begin data[idx]<=mem_rdata; tags[idx]<=addr[31:9];
                    valids[idx]<=1; line_out<=mem_rdata; line_valid<=1; mem_valid<=0; end
            end
        end else begin line_valid<=0; mem_valid<=0; end
    end
    assign mem_addr = {{addr[31:9], 9'd0}};
endmodule
'''


def _gen_dcache(cfg: dict) -> str:
    sz = cfg["l1d_cache_kb"]
    sets = max(16, sz // 2)
    return f'''// DCache {sz}KB
module {cfg['design_name']}_dcache #(
    parameter SIZE_KB=16
) (
    input  wire        clock, reset,
    input  wire [31:0] addr, input wire [63:0] wdata, input wire [7:0] strb,
    input  wire        req_valid, output reg ack,
    output wire [31:0] mem_addr, output reg [63:0] mem_wdata,
    output reg  [7:0]  mem_strb, output reg mem_valid, input mem_ready,
    input  wire [63:0] mem_rdata
);
    localparam SETS = {sets};
    reg [63:0] data [0:SETS-1];
    reg [31:9] tag [0:SETS-1];
    reg        valids [0:SETS-1];
    wire [$clog2(SETS)-1:0] idx = addr[8+$clog2(SETS)-1:9];
    wire hit = valids[idx] && (tag[idx]==addr[31:9]);
    always @(posedge clock) begin
        if (reset) begin ack<=0; mem_valid<=0; end
        else if (req_valid) begin
            if (hit) begin data[idx]<=wdata; ack<=1; end
            else begin mem_valid<=1; mem_wdata<=wdata; mem_strb<=strb;
                if (mem_ready) begin data[idx]<=mem_rdata; tag[idx]<=addr[31:9];
                    valids[idx]<=1; ack<=1; mem_valid<=0; end
            end
        end else ack<=0;
    end
    assign mem_addr = {{addr[31:9], 9'd0}};
endmodule
'''


def _gen_exe_units(cfg: dict) -> str:
    return f'''// Execution Units
module {cfg['design_name']}_exe_units #(
    parameter ISA="RV64GC"
) (
    input  wire        clock, reset,
    input  wire [31:0] inst,
    input  wire [63:0] rs1_data, rs2_data,
    output reg  [63:0] result
);
    wire [6:0] op=inst[6:0]; wire [2:0] f3=inst[14:12]; wire [6:0] f7=inst[31:25];
    wire signed [63:0] s1=rs1_data, s2=rs2_data;
    always @(*) begin
        result=64'd0;
        if (op==7'b0110011 && f3==3'b000 && f7==7'b0000000) result=rs1_data+rs2_data;
        else if (op==7'b0110011 && f3==3'b000 && f7==7'b0100000) result=rs1_data-rs2_data;
        else if (op==7'b0110011 && f3==3'b010) result={{63'd0, s1<s2}};
        else if (op==7'b0110011 && f3==3'b111) result=rs1_data&rs2_data;
        else if (op==7'b0110011 && f3==3'b110) result=rs1_data|rs2_data;
        else if (op==7'b0110011 && f3==3'b100) result=rs1_data^rs2_data;
        else if (op==7'b0110011 && f3==3'b001) result=rs1_data<<rs2_data[5:0];
        else if (op==7'b0110011 && f3==3'b101 && f7==7'b0000000) result=rs1_data>>rs2_data[5:0];
        else if (op==7'b0110111) result={{inst[31:12],12'd0}};
        else if (op==7'b0000011) result=rs1_data+{{52'd0,inst[31:20]}};
    end
endmodule
'''


def _gen_regfile(cfg: dict) -> str:
    xlen = 64 if "64" in cfg["isa"] else 32
    return f'''// Register File 32x{xlen}
module {cfg['design_name']}_regfile #(
    parameter ISA="RV64GC"
) (
    input  wire        clock, reset,
    input  wire [4:0]  rs1, rs2, rd,
    input  wire        we, input wire [63:0] wdata,
    output reg  [63:0] rdata1, rdata2
);
    reg [63:0] rf [0:31];
    integer i;
    always @(posedge clock) begin
        if (reset) for(i=0;i<32;i++) rf[i]<=0;
        else begin
            if (we && rd!=0) rf[rd]<=wdata;
            rdata1<=rf[rs1]; rdata2<=rf[rs2];
        end
    end
endmodule
'''


def _gen_hazard(cfg: dict) -> str:
    return f'''// Hazard Detection
module {cfg['design_name']}_hazard (
    input wire [4:0] ex_rd, mem_rd, wb_rd,
    input wire ex_we, mem_we, wb_we,
    input wire [4:0] if_rs1, if_rs2,
    output reg stall, flush
);
    wire ex_haz = ex_we && |ex_rd && (ex_rd==if_rs1 || ex_rd==if_rs2);
    wire mem_haz = mem_we && |mem_rd && (mem_rd==if_rs1 || mem_rd==if_rs2);
    always @* begin stall=ex_haz||mem_haz; flush=0; end
endmodule
'''


def _gen_tilelink(cfg: dict) -> str:
    n = cfg["num_cores"]
    l2 = cfg["l2_cache_kb"]
    return f'''// TileLink Interconnect
module {cfg['design_name']}_tilelink #(
    parameter N_CORES={n}, parameter L2_SIZE={l2}
) (
    input  wire        clock, reset,
    input  wire [31:0] core_addr,
    input  wire        core_valid,
    output wire        core_ready,
    output wire [63:0] core_rdata,
    output wire        core_rvalid,
    output wire [31:0] mem_req_addr,
    output wire [63:0] mem_resp_data,
    output wire        mem_resp_valid
);
    localparam SETS = L2_SIZE/4;
    reg [127:0] l2_data [0:SETS-1];
    reg [31:9]  l2_tag [0:SETS-1];
    reg         l2_valid [0:SETS-1];
    reg [1:0]   beat=0;
    reg [127:0] line_buf=0;
    reg         rvalid=0;
    wire [9:0]  idx = core_addr[7+:10];
    wire        l2_hit = l2_valid[idx] && (l2_tag[idx]==core_addr[31:9]);
    assign core_ready = l2_hit || 1'b1;
    assign core_rvalid = rvalid;
    assign core_rdata = line_buf[63:0];
    assign mem_req_addr = core_addr;
    assign mem_resp_data = 64'd0;
    assign mem_resp_valid = 1'b0;
    always @(posedge clock) begin
        if (reset) begin rvalid<=0; beat<=0; end
        else begin
            if (core_valid && !rvalid) begin
                if (l2_hit) begin core_rdata<=l2_data[idx][63:0]; rvalid<=1; end
            end
        end
    end
endmodule
'''

def _gen_sram_macros() -> str:
    """生成 SRAM 黑盒模块 — Yosys 综合需要明确定义所有引用的模块"""
    return '''// ─── SRAM Black-Box Modules (for Yosys synthesis) ───────────────────────────
// 这些模块由 Chipyard 工具链生成，此处提供黑盒声明供综合使用
// 实际物理实现由 ORFS 的 .lef/.lib 描述

module data_arrays_0(RW0_addr, RW0_en, RW0_clk, RW0_wmode,
                     RW0_wdata_0, RW0_wdata_1, RW0_wdata_2, RW0_wdata_3,
                     RW0_rdata_0, RW0_rdata_1, RW0_rdata_2, RW0_rdata_3);
  parameter DATA_WIDTH = 32;
  parameter SIZE = 256;
  input  [5:0]  RW0_addr;
  input          RW0_en, RW0_clk, RW0_wmode;
  input  [7:0]  RW0_wdata_0, RW0_wdata_1, RW0_wdata_2, RW0_wdata_3;
  output [7:0]  RW0_rdata_0, RW0_rdata_1, RW0_rdata_2, RW0_rdata_3;
endmodule

module data_arrays_0_0(RW0_addr, RW0_en, RW0_clk, RW0_wmode,
                        RW0_wdata, RW0_rdata);
  input  [6:0]  RW0_addr;
  input         RW0_en, RW0_clk, RW0_wmode;
  input  [31:0] RW0_wdata;
  output [31:0] RW0_rdata;
endmodule

module tag_array(RW0_addr, RW0_en, RW0_clk, RW0_wmode, RW0_wdata, RW0_rdata);
  input  [5:0]  RW0_addr;
  input         RW0_en, RW0_clk, RW0_wmode;
  input  [27:0] RW0_wdata;
  output [27:0] RW0_rdata;
endmodule
'''


# ═══════════════════════════════════════════════════════════════════════════════
# 主程序
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="TinyRocket RTL 生成")
    parser.add_argument("--design", default="tinyRocket")
    parser.add_argument("--instruction",
        default="请帮我生成一个tinyRocket处理器并完成后端全流程")
    parser.add_argument("--config", help="JSON 配置文件")
    args = parser.parse_args()

    print("=" * 60)
    print("  TinyRocket RTL 生成器 (工具3: Chipyard 框架)")
    print("=" * 60)

    # ── 1. 解析配置 ────────────────────────────────────────────────────────
    print("\n[1/4] 解析自然语言指令...")
    cfg = json.load(open(args.config)) if args.config else parse_instruction(args.instruction)
    cfg["design_name"] = args.design
    print(f"  ISA: {cfg['isa']}, 核数: {cfg['num_cores']}, "
          f"频率: {cfg['freq_mhz']}MHz, L2: {cfg['l2_cache_kb']}KB")

    # ── 2. 生成需求规格 ────────────────────────────────────────────────────
    print("\n[2/4] 生成需求规格文档...")
    spec = generate_requirement_spec(cfg, args.instruction)
    (AGENT_LOGS / "requirement_spec.md").write_text(spec)
    print(f"  已保存: agent/logs/requirement_spec.md")

    # ── 3. 检查 Chipyard 容器 ─────────────────────────────────────────────
    print("\n[3/4] 检查 Chipyard 环境...")
    cy_status = check_chipyard_status()
    print(f"  容器运行: {'是' if cy_status['container_running'] else '否'}")
    print(f"  Chipyard 源码: {'是' if cy_status['chipyard_source'] else '否 (需克隆)'}")
    print(f"  Java: {'是' if cy_status['java_available'] else '否'}")

    # ── 4. RTL 生成策略 ────────────────────────────────────────────────────
    print("\n[4/4] 生成 Verilog RTL...")

    output_files = []

    # 策略1: 从 ORFS 容器复制预生成 RTL
    output_files = copy_orfs_rtl(cfg)

    # 策略2: 如果 ORFS RTL 不可用，使用内置生成器
    if not output_files:
        print("\n  [RTL] ORFS RTL 不可用，使用内置生成器...")
        output_files = generate_fallback_rtl(cfg)

    # 同步到 ORFS 容器工作区
    print("\n  同步 RTL 到 ORFS 工作区...")
    subprocess.run(["docker", "exec", "orfs-agent", "mkdir", "-p",
                   "/workspace/design/rtl"], check=False)
    subprocess.run(["docker", "exec", "orfs-agent", "mkdir", "-p",
                   "/workspace/design/constraints"], check=False)
    for f in output_files:
        subprocess.run(["docker", "cp", str(f),
                       f"orfs-agent:/workspace/design/rtl/{f.name}"], check=True)

    # 生成 SDC 约束
    sdc = generate_sdc(cfg)
    sdc_file = PROJECT_DIR / "design" / "constraints" / f"{args.design}.sdc"
    sdc_file.write_text(sdc)
    subprocess.run(["docker", "cp", str(sdc_file),
                   "orfs-agent:/workspace/design/constraints/constraint.sdc"], check=True)
    print(f"  [生成] {args.design}.sdc")

    # 保存配置
    cfg["instruction"] = args.instruction
    cfg["rtl_files"] = [str(f) for f in output_files]
    cfg["generated_at"] = datetime.now().isoformat()
    (LOGS_DIR / "rtl_gen_config.json").write_text(
        json.dumps(cfg, indent=2, ensure_ascii=False))

    print(f"\n  生成文件数: {len(output_files)}")
    for f in output_files:
        sz = f.stat().st_size // 1024
        print(f"    {f.name} ({sz}KB)")

    print(f"\n  Chipyard 容器状态: {'就绪' if cy_status['chipyard_source'] else '未配置 (源码未挂载)'}")
    print("\n[完成] RTL 生成阶段结束")
    return 0


if __name__ == "__main__":
    sys.exit(main())
