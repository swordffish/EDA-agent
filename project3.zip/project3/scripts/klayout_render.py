#!/usr/bin/env python3
"""
KLayout GDS → PNG 渲染器（使用 KLayout Python API）
"""
import sys
from pathlib import Path

# KLayout Python API
try:
    import pya
    HAS_PYKLAYOUT = True
except ImportError:
    HAS_PYKLAYOUT = False
    print("[ERROR] pya module not available. Install KLayout with Python API.")
    sys.exit(1)

def render_gds(gds_path: str, png_path: str, scale: float = 3.0, top_cell: str = None):
    """用 KLayout Python API 渲染 GDS"""
    gds_file = Path(gds_path)
    if not gds_file.exists():
        print(f"[ERROR] GDS 文件不存在: {gds_path}")
        return False

    print(f"  加载 GDS: {gds_file}")

    # 读取 GDS
    layout = pya.Layout()
    layout.read(str(gds_file))

    # 选择顶层单元
    if top_cell:
        for tc in layout.top_cells():
            if tc.name == top_cell:
                top = tc
                break
        else:
            top = layout.top_cells()[0]
    else:
        top = layout.top_cells()[0]

    print(f"  顶层单元: {top.name}")
    bbox = top.bbox()
    print(f"  边界框: {bbox}")
    dbu = layout.dbu  # database units per micron

    # 创建应用实例和主窗口
    app = pya.Application.instance()
    if not app:
        app = pya.Application()

    mw = pya.MainWindow.current()
    if not mw:
        mw = pya.MainWindow.create()

    # 创建新的布局视图（私有模式）
    lv = mw.create_layout_view(0)
    lv.set_cell(top.cell_index())
    lv.max_hier()

    # 适应视图
    lv.zoom_fit()

    # 计算输出尺寸
    pixel_scale = scale  # 3 pixels per database unit
    width = int(bbox.width() * dbu * pixel_scale)
    height = int(bbox.height() * dbu * pixel_scale)
    width = max(width, 800)
    height = max(height, 600)

    print(f"  输出尺寸: {width} × {height} px (scale={scale})")

    # 生成像素图
    img = lv.get_pixmap(
        pya.Viewer.PixelRatio,  # pixel ratio
        width,   # canvas width
        height,  # canvas height
        pixel_scale  # pixels per database unit
    )

    img.save(png_path)
    print(f"  PNG 已保存: {png_path} ({img.width()}×{img.height()} px)")
    return True


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="KLayout GDS → PNG 渲染")
    ap.add_argument("gds", type=str, help="GDS 输入文件")
    ap.add_argument("png", type=str, help="PNG 输出文件")
    ap.add_argument("--scale", type=float, default=3.0, help="缩放比例（默认 3.0）")
    ap.add_argument("--top-cell", type=str, default=None, help="顶层单元名")
    args = ap.parse_args()

    if render_gds(args.gds, args.png, args.scale, args.top_cell):
        print("✓ 完成")
    else:
        print("✗ 失败")
        sys.exit(1)
