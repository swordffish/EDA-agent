#!/bin/bash
# Chipyard 初始化脚本
# 位置: /root/init-chipyard.sh

set -e

# 设置 Java PATH
export PATH=/root/miniforge3/pkgs/openjdk-17.0.3-h4335b31_6/bin:$PATH

echo "[1/4] Cloning Chipyard v1.9.1..."
git clone --depth 1 --branch v1.9.1 https://github.com/ucb-bar/chipyard.git /root/chipyard

echo "[2/4] Initializing submodules..."
cd /root/chipyard
./scripts/init-submodules.sh

echo "[3/4] Building Chipyard dependencies..."
./scripts/build-setup.sh

echo "[4/4] Verifying Chisel/FIRRTL..."
./sbt "project firewall; compile"

echo "Chipyard initialization complete!"
