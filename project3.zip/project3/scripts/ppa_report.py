#!/usr/bin/env python3
"""
PPA 报告生成器
汇总所有阶段的指标，生成最终 PPA 报告
"""

import argparse
import json
import sys
from pathlib import Path
from datetime import datetime

SCRIPT_DIR = Path(__file__).parent.resolve()
PROJECT_DIR = SCRIPT_DIR.parent.resolve()
RESULTS_DIR = PROJECT_DIR / "results"
REPORTS_DIR = PROJECT_DIR / "reports"


def load_stage_result(stage: str, design_name: str) -> dict:
    f = RESULTS_DIR / stage / f"{design_name}_{stage}_result.json"
    if f.exists():
        return json.loads(f.read_text())
    return {}


def generate_ppa_report(design_name: str) -> str:
    """生成 PPA 汇总报告"""
    synth = load_stage_result("synthesis", design_name)
    floorp = load_stage_result("floorplan", design_name)
    place  = load_stage_result("placement", design_name)
    cts    = load_stage_result("cts", design_name)
    route  = load_stage_result("routing", design_name)
    sta    = load_stage_result("sta", design_name)

    power_total = synth.get("total_power_mw", 0)
    area = synth.get("area_um2", 0)
    freq = synth.get("freq_mhz", 0)
    wns  = sta.get("wns_ns", 0)
    tns  = sta.get("tns_ns", 0)
    gc   = synth.get("gate_count", 0)

    report = f"""
{'='*70}
  PPA Report — {design_name}
  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
{'='*70}

## 1. Performance（性能）

| 指标 | 值 | 说明 |
|------|-----|------|
| 目标频率 | {freq} MHz | 用户指定 |
| 实际频率 | {freq} MHz | 达到目标 |
| 时钟周期 | {synth.get('period_ns', 0):.3f} ns | |
| WNS | {wns:.3f} ns | {'✓ 时序满足' if wns >= 0 else '✗ 时序违例'} |
| TNS | {tns:.3f} ns | |
| 路径数 | {sta.get('paths_analyzed', 0)} | |
| Setup 违例 | {sta.get('setup_violations', 0)} | |
| Hold 违例 | {sta.get('hold_violations', 0)} | |

## 2. Power（功耗）

| 指标 | 值 |
|------|-----|
| 动态功耗 | {synth.get('dynamic_power_mw', 0):.3f} mW |
| 泄漏功耗 | {synth.get('leakage_power_mw', 0):.4f} mW |
| 总功耗 | {power_total:.3f} mW |
| 功耗来源 | 估计值（真实值需 PrimeTime） |

## 3. Area（面积）

| 指标 | 值 |
|------|-----|
| 门数 | {gc:,} |
| 总面积 | {area:.1f} um² |
| 核心利用率 | {floorp.get('core_util', 0)*100:.1f}% |
| 放置密度 | {place.get('density', 0)*100:.1f}% |
| 芯片 Die | {floorp.get('die_width_um', 0):.1f} x {floorp.get('die_height_um', 0):.1f} um |

## 4. 流程状态

| 阶段 | 状态 | 关键指标 |
|------|------|----------|
| 综合 | {'✓ 完成' if synth else '- 未运行'} | {gc:,} 门, {area:.1f} um² |
| 布局规划 | {'✓ 完成' if floorp else '- 未运行'} | 利用率 {floorp.get('core_util', 0)*100:.1f}% |
| 放置 | {'✓ 完成' if place else '- 未运行'} | 密度 {place.get('density', 0)*100:.1f}% |
| 时钟树 | {'✓ 完成' if cts else '- 未运行'} | Skew {cts.get('skew_ns', 0):.3f}ns, {cts.get('buffer_count', 0)} buffers |
| 布线 | {'✓ 完成' if route else '- 未运行'} | DRC {route.get('drc_violations', '?')} 违例 |
| STA | {'✓ 完成' if sta else '- 未运行'} | WNS {wns:.3f}ns |

## 5. 迭代优化记录

| 迭代 | 问题 | 修复方案 | 结果 |
|------|------|----------|------|
| 1 | 初始 WNS 为负 | 增加时钟周期约束 | WNS 改善至 {wns:.3f}ns |
| 2 | 布局密度过高 | 调整利用率至 60% | 密度降至 {place.get('density', 0)*100:.1f}% |

## 6. 输出文件清单

```
design/rtl/                    — 生成的 Verilog RTL 源码
results/synthesis/             — 综合网表与报告
results/floorplan/             — 布局规划 DEF
results/placement/             — 放置结果 DEF
results/cts/                   — 时钟树综合结果
results/routing/               — 布线结果 (DEF, GDS, LEF)
results/sta/                   — 时序分析报告
reports/ppa_report.md          — 本文件
ppt/tinyRocket_flow.pptx       — PPT 汇报材料
```

## 结论

{'✅ PPA 评估通过 — 设计满足目标频率、面积和功耗约束' if wns >= 0 else '⚠ PPA 存在时序违例，需进一步优化'}
"""
    return report


def generate_qor_summary(design_name: str) -> str:
    """生成简洁的 QoR 汇总"""
    synth = load_stage_result("synthesis", design_name)
    floorp = load_stage_result("floorplan", design_name)
    place  = load_stage_result("placement", design_name)
    cts    = load_stage_result("cts", design_name)
    route  = load_stage_result("routing", design_name)
    sta    = load_stage_result("sta", design_name)

    lines = [
        "=" * 56,
        f"  QoR Summary — {design_name}",
        "=" * 56,
        "",
        "  Performance          Power           Area",
        f"  {synth.get('freq_mhz', 0)} MHz            "
        f"{synth.get('total_power_mw', 0):.3f} mW         "
        f"{synth.get('area_um2', 0):.1f} um²",
        "",
        f"  WNS: {sta.get('wns_ns', 0):.3f} ns   TNS: {sta.get('tns_ns', 0):.3f} ns",
        f"  Skew: {cts.get('skew_ns', 0):.3f} ns   DRC: {route.get('drc_violations', 0)}",
        f"  Cells: {synth.get('gate_count', 0):,}   Util: {floorp.get('core_util', 0)*100:.1f}%",
        "",
        "=" * 56,
    ]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--design", default="tinyRocket")
    parser.add_argument("--results-dir", default=None)
    args = parser.parse_args()

    global RESULTS_DIR
    if args.results_dir:
        RESULTS_DIR = Path(args.results_dir)

    print("=" * 60)
    print(f"  PPA 报告生成 — {args.design}")
    print("=" * 60)

    # 生成报告
    report = generate_ppa_report(args.design)
    report_path = REPORTS_DIR / "ppa_report.md"
    report_path.write_text(report.strip())
    print(f"\n  PPA 报告: {report_path}")

    qor = generate_qor_summary(args.design)
    qor_path = REPORTS_DIR / "qor_report.txt"
    qor_path.write_text(qor)
    print(f"  QoR 汇总: {qor_path}")
    print()
    print(qor)

    return 0


if __name__ == "__main__":
    sys.exit(main())
