#!/usr/bin/env python3
"""
PPA 参数优化脚本
===========================
策略：读取实际后端流程结果，迭代调参，记录每次调整的原因与效果。

迭代流程：
  1. 读取当前基准（实际后端结果）
  2. 分析 PPA 短板（时序/面积/功耗）
  3. 选择优化方向，执行参数调整
  4. 重新运行后端流程
  5. 对比效果，记录到迭代历史
  6. 收敛或达到最大迭代次数
"""

import argparse
import json
import math
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent.resolve()
PROJECT_DIR = SCRIPT_DIR.parent.resolve()
RESULTS_DIR = PROJECT_DIR / "results"
REPORTS_DIR = PROJECT_DIR / "reports"
LOGS_DIR    = PROJECT_DIR / "logs"
OPT_DIR     = RESULTS_DIR / "optimization"

ORFS_CONTAINER = "orfs-agent"
ORFS_WORKSPACE = "/workspace/design"
ORFS_FLOW_DIR  = "/OpenROAD-flow-scripts/flow"

for d in [OPT_DIR, REPORTS_DIR, LOGS_DIR]:
    d.mkdir(parents=True, exist_ok=True)


# ═══════════════════════════════════════════════════════════════════════════════
# 优化策略类
# ═══════════════════════════════════════════════════════════════════════════════

class OptimizationStrategy:
    """单次优化尝试 — 包含原因、参数变化、预期效果"""

    def __init__(self, name: str, short_name: str,
                 reason: str,           # 为什么要这样做
                 param_delta: dict,     # 参数变化 {param_name: (old, new)}
                 expected_effect: str,  # 预期效果
                 reverse_on_fail: bool = True):
        self.name = name
        self.short_name = short_name
        self.reason = reason
        self.param_delta = param_delta
        self.expected_effect = expected_effect
        self.reverse_on_fail = reverse_on_fail

    def describe_delta(self) -> str:
        return ", ".join(
            f"{k}: {v[0]}→{v[1]}"
            for k, v in self.param_delta.items()
        )


# 预定义优化策略（按优先级排序）
STRATEGIES = [
    # ── S1: 时序优化 ────────────────────────────────────────────────────
    OptimizationStrategy(
        name="S1-timing-cellpad",
        short_name="时序-增加单元间距",
        reason=(
            "分析: 当前 WNS=+0.144ns，裕量较小（<0.2ns）。"
            "增加 CELL_PAD_IN_SITES 可在绕线阶段为关键路径提供更多布线空间，"
            "减少耦合延迟，预计 WNS 改善约 0.02-0.05ns。"
        ),
        param_delta={
            "cell_pad_global": (0, 2),
            "cell_pad_detail": (0, 2),
        },
        expected_effect="WNS 预计改善 +0.02~+0.05ns；面积可能增加 2-4%",
        reverse_on_fail=True,
    ),

    # ── S2: 面积优化 ────────────────────────────────────────────────────
    OptimizationStrategy(
        name="S2-area-high-util",
        short_name="面积-提高利用率",
        reason=(
            "分析: 当前利用率 60%，面积有冗余空间。"
            "提高 CORE_UTILIZATION 至 68% 可在保持 DRC=0 的前提下"
            "减少芯片面积约 12%，降低制造成本。"
        ),
        param_delta={
            "core_util": (60, 68),
            "place_density": (0.68, 0.75),
        },
        expected_effect="面积预计减少 10-15%；拥塞风险略有上升，需监控 DRC",
        reverse_on_fail=True,
    ),

    # ── S3: 时钟树优化 ──────────────────────────────────────────────────
    OptimizationStrategy(
        name="S3-cts-buffer",
        short_name="时钟-增加缓冲器",
        reason=(
            "分析: 当前 Skew=0.20ns，接近 0.5ns 阈值但仍有裕量。"
            "适度增加时钟缓冲器密度（CTS_BUF_DISTANCE: 100→80）"
            "可进一步降低 skew 至 <0.15ns，提升时序稳定性。"
        ),
        param_delta={
            "cts_buf_distance": (100.0, 80.0),
        },
        expected_effect="Skew 预计降至 <0.15ns；功耗略微增加",
        reverse_on_fail=True,
    ),

    # ── S4: 频率提升 ────────────────────────────────────────────────────
    OptimizationStrategy(
        name="S4-freq-boost",
        short_name="频率-提高目标频率",
        reason=(
            "分析: 当前 WNS=+0.144ns，有约 12% 的时钟周期裕量。"
            "将目标频率从 833MHz 提升至 909MHz（周期 1.1ns），"
            "测试设计在更高频率下的时序余量，为性能优化提供数据。"
        ),
        param_delta={
            "target_period_ns": (1.2, 1.1),
        },
        expected_effect="频率提升至 909MHz；WNS 应仍为正，否则回退",
        reverse_on_fail=True,
    ),

    # ── S5: 密度降低防拥塞 ─────────────────────────────────────────────
    OptimizationStrategy(
        name="S5-congestion-relief",
        short_name="拥塞-降低密度",
        reason=(
            "分析: 若 S2 面积优化导致 DRC 违例或拥塞峰值 >0.5，"
            "需要降低布局密度缓解。PLACE_DENSITY 从 0.75 降至 0.70，"
            "牺牲少量面积换取 DRC 清洁和绕线质量。"
        ),
        param_delta={
            "place_density": (0.75, 0.70),
        },
        expected_effect="拥塞缓解，DRC 降至 0；面积小幅增加",
        reverse_on_fail=False,
    ),

    # ── S6: 激进频率测试 ───────────────────────────────────────────────
    OptimizationStrategy(
        name="S6-freq-aggressive",
        short_name="频率-激进目标",
        reason=(
            "分析: 测试 tinyRocket 在 1GHz (period=1.0ns) 下的时序表现。"
            "若 WNS ≥ 0，则设计可支持 1GHz；若严重违例，"
            "则确定频率上限为当前 909MHz。"
        ),
        param_delta={
            "target_period_ns": (1.1, 1.0),
        },
        expected_effect="频率 1GHz；WNS 应 ≥0 才算成功",
        reverse_on_fail=True,
    ),
]


# ═══════════════════════════════════════════════════════════════════════════════
# 实际结果读取
# ═══════════════════════════════════════════════════════════════════════════════

def load_actual_results(design_name: str) -> dict:
    """从 flow_state.json 读取实际后端结果"""
    state_file = RESULTS_DIR / "flow_state.json"
    if not state_file.exists():
        return {}
    return json.loads(state_file.read_text())


def extract_ppa(state: dict) -> dict:
    """从 flow_state 提取 PPA 指标"""
    stages = state.get("stages", {})
    synth = stages.get("synthesis", {})
    sta = stages.get("sta", {})
    cts = stages.get("cts", {})
    route = stages.get("routing", {})
    floor = stages.get("floorplan", {})

    return {
        "gate_count":     synth.get("gate_count", 0),
        "area_um2":       synth.get("area_um2", 0),
        "freq_mhz":       synth.get("freq_mhz", 0),
        "period_ns":      synth.get("period_ns", 0),
        "wns_ns":         sta.get("wns_ns", 0),
        "tns_ns":         sta.get("tns_ns", 0),
        "skew_ns":        cts.get("skew_ns", 0),
        "drc_violations": route.get("drc_violations", 0),
        "congestion_avg": route.get("congestion_avg", 0),
        "congestion_peak": route.get("congestion_peak", 0),
        "utilization":    floor.get("core_util", 0),
        "density":        stages.get("placement", {}).get("density", 0),
        "total_power_mw": synth.get("total_power_mw", 0),
        "dynamic_power_mw": synth.get("dynamic_power_mw", 0),
        "leakage_power_mw": synth.get("leakage_power_mw", 0),
        "buffer_count":   cts.get("buffer_count", 0),
        "elapsed_s":      sum(
            s.get("elapsed_s", 0) for s in stages.values()
        ),
    }


def ppa_score(ppa: dict) -> float:
    """计算 PPA 综合评分（越高越好）"""
    wns = ppa.get("wns_ns", 0)
    area_mm2 = ppa.get("area_um2", 0) / 1e6
    power_mw = ppa.get("total_power_mw", 0)
    freq_mhz = ppa.get("freq_mhz", 0)
    drc = ppa.get("drc_violations", 0)

    # 各项归一化（权重可调）
    area_score  = max(0, 1.0 - area_mm2 / 1.0) * 30          # 面积越小越好
    power_score = max(0, 1.0 - power_mw / 10.0) * 20         # 功耗越低越好
    freq_score  = (freq_mhz / 1000.0) * 30                   # 频率越高越好
    timing_score = (wns + 0.5) / 0.5 * 20 if wns >= -0.5 else 0  # WNS 越正越好
    drc_score   = 20 if drc == 0 else max(0, 10 - drc)

    return round(area_score + power_score + freq_score + timing_score + drc_score, 2)


# ═══════════════════════════════════════════════════════════════════════════════
# 参数应用
# ═══════════════════════════════════════════════════════════════════════════════

# 当前生效的参数（运行时动态更新）
CURRENT_PARAMS = {
    "core_util": 60,
    "place_density": 0.68,
    "cell_pad_global": 0,
    "cell_pad_detail": 0,
    "cts_buf_distance": 100.0,
    "target_period_ns": 1.2,
    "core_aspect_ratio": 1.0,
    "core_margin": 2,
}


def apply_strategy(strategy: OptimizationStrategy) -> bool:
    """将优化策略参数应用到 config.mk，返回是否成功"""
    # 更新当前参数
    for param, (_, new_val) in strategy.param_delta.items():
        CURRENT_PARAMS[param] = new_val

    config_mk = _build_config_mk()
    ok, _, _ = _docker_exec(ORFS_CONTAINER, ["bash", "-c",
        f"echo '{config_mk}' > {ORFS_WORKSPACE}/settings.mk"
    ])
    return ok


def revert_strategy(strategy: OptimizationStrategy) -> bool:
    """回退策略的参数变更"""
    for param, (old_val, _) in strategy.param_delta.items():
        CURRENT_PARAMS[param] = old_val

    config_mk = _build_config_mk()
    ok, _, _ = _docker_exec(ORFS_CONTAINER, ["bash", "-c",
        f"echo '{config_mk}' > {ORFS_WORKSPACE}/settings.mk"
    ])
    return ok


def _build_config_mk() -> str:
    freq_mhz = round(1000.0 / CURRENT_PARAMS["target_period_ns"], 1)
    return f"""export DESIGN_HOME = /OpenROAD-flow-scripts/flow/designs/src
export DESIGN_NICKNAME = tinyRocket
export DESIGN_NAME = RocketTile
export PLATFORM    = nangate45

export VERILOG_FILES = $(sort $(wildcard $(DESIGN_HOME)/$(DESIGN_NICKNAME)/*.v))
export SDC_FILE      = $(DESIGN_HOME)/$(DESIGN_NICKNAME)/constraint.sdc

export ADDITIONAL_LEFS = $(sort $(wildcard $(DESIGN_HOME)/$(PLATFORM)/$(DESIGN_NICKNAME)/*.lef))
export ADDITIONAL_LIBS = $(sort $(wildcard $(DESIGN_HOME)/$(PLATFORM)/$(DESIGN_NICKNAME)/*.lib))

# ── PPA 优化参数 ──────────────────────────────────────────────────────────
export CORE_UTILIZATION       = {CURRENT_PARAMS['core_util']}
export PLACE_DENSITY         = {CURRENT_PARAMS['place_density']}
export CORE_ASPECT_RATIO     = {CURRENT_PARAMS['core_aspect_ratio']}
export CORE_MARGIN           = {CURRENT_PARAMS['core_margin']}
export CELL_PAD_IN_SITES_GLOBAL_PLACEMENT = {CURRENT_PARAMS['cell_pad_global']}
export CELL_PAD_IN_SITES_DETAIL_PLACEMENT = {CURRENT_PARAMS['cell_pad_detail']}
export CTS_BUF_DISTANCE      = {CURRENT_PARAMS['cts_buf_distance']}

# Clock: {freq_mhz} MHz = {CURRENT_PARAMS['target_period_ns']} ns
"""


# ═══════════════════════════════════════════════════════════════════════════════
# 实际流程运行
# ═══════════════════════════════════════════════════════════════════════════════

def _docker_exec(container: str, cmd: list, timeout: int = 300) -> tuple:
    full = ["docker", "exec", container] + cmd
    try:
        r = subprocess.run(full, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return False, "", "timeout"


def run_backend_stage(stage: str, timeout: int = 300) -> tuple:
    """运行单个后端阶段，返回 (ok, stdout)"""
    stage_map = {
        "synthesis": "synth", "floorplan": "floorplan",
        "placement": "place", "cts": "cts",
        "routing": "route", "sta": "finish",
    }
    cmd_name = stage_map.get(stage, stage)
    cmd = ["bash", "-c",
           f"cd {ORFS_FLOW_DIR} && "
           f"make DESIGN_CONFIG={ORFS_WORKSPACE}/settings.mk "
           f"{cmd_name} 2>&1 | tail -10"
           ]
    return _docker_exec(ORFS_CONTAINER, cmd, timeout=timeout)


def run_full_flow() -> dict:
    """运行完整后端流程（使用当前 config.mk），返回结果"""
    start = time.time()
    stage_names = ["synthesis", "floorplan", "placement", "cts", "routing", "sta"]

    for stage in stage_names:
        ok, _ = run_backend_stage(stage)
        if not ok:
            elapsed = time.time() - start
            return {"error": f"{stage} failed", "elapsed_s": round(elapsed, 1)}

    elapsed = time.time() - start
    state = load_actual_results("tinyRocket")
    ppa = extract_ppa(state)
    ppa["elapsed_s"] = round(elapsed, 1)
    ppa["score"] = ppa_score(ppa)
    return ppa


# ═══════════════════════════════════════════════════════════════════════════════
# 迭代历史管理
# ═══════════════════════════════════════════════════════════════════════════════

class OptimizationHistory:
    """优化迭代历史"""

    def __init__(self, design_name: str):
        self.design_name = design_name
        self.iterations = []   # 每次迭代的完整记录
        self.best_score = 0.0
        self.best_ppa = None
        self.best_iteration = 0

    def add_iteration(self, iter_num: int, strategy: OptimizationStrategy,
                      before: dict, after: dict,
                      converged: bool = False):
        """记录一次迭代"""
        # 计算变化
        delta = {}
        for key in ["wns_ns", "area_um2", "freq_mhz", "total_power_mw",
                    "skew_ns", "drc_violations", "utilization", "density"]:
            b = before.get(key, 0)
            a = after.get(key, 0)
            if b and a and b != 0:
                delta[f"delta_{key}"] = round(a - b, 4)
                delta[f"pct_{key}"] = round((a - b) / b * 100, 2) if b != 0 else 0

        # 判断是否改善
        improved = after.get("wns_ns", -999) >= before.get("wns_ns", -999)

        entry = {
            "iteration": iter_num,
            "strategy": {
                "name": strategy.name,
                "short_name": strategy.short_name,
                "reason": strategy.reason,
                "param_delta": strategy.param_delta,
                "describe_delta": strategy.describe_delta(),
                "expected_effect": strategy.expected_effect,
            },
            "before": {k: before.get(k, 0) for k in
                       ["wns_ns", "area_um2", "freq_mhz", "total_power_mw",
                        "skew_ns", "drc_violations", "utilization", "density"]},
            "after": {k: after.get(k, 0) for k in
                      ["wns_ns", "area_um2", "freq_mhz", "total_power_mw",
                       "skew_ns", "drc_violations", "utilization", "density"]},
            "delta": delta,
            "improved": improved,
            "converged": converged,
            "timestamp": datetime.now().isoformat(),
        }

        self.iterations.append(entry)

        # 更新最优
        score = after.get("score", 0)
        if score > self.best_score:
            self.best_score = score
            self.best_ppa = after.copy()
            self.best_iteration = iter_num

    def to_dict(self) -> dict:
        return {
            "design_name": self.design_name,
            "total_iterations": len(self.iterations),
            "best_score": self.best_score,
            "best_iteration": self.best_iteration,
            "best_ppa": self.best_ppa,
            "iterations": self.iterations,
        }

    def summary_md(self) -> str:
        """生成 Markdown 格式的迭代摘要"""
        rows = []
        for it in self.iterations:
            s = it["strategy"]
            delta = it["delta"]
            wns_b = it["before"].get("wns_ns", 0)
            wns_a = it["after"].get("wns_ns", 0)
            area_b = it["before"].get("area_um2", 0)
            area_a = it["after"].get("area_um2", 0)
            icon = "✓" if it["improved"] else "✗"

            wns_str = (f"{wns_b:+.3f}ns → {wns_a:+.3f}ns"
                       f" ({delta.get('delta_wns_ns',0):+.4f})")
            area_str = (f"{area_b/1000:.1f}k → {area_a/1000:.1f}k"
                        f" ({delta.get('delta_area_um2',0):+.0f}μm²)")

            rows.append(
                f"| {it['iteration']} | {s['short_name']} | "
                f"{s.get('describe_delta', '-')} | "
                f"{wns_str} | {area_str} | "
                f"{'⚠' if it['converged'] else icon} |"
            )

        best = self.best_iteration
        best_row = next((r for r in self.iterations if r["iteration"] == best), None)

        return f"""# PPA 优化迭代记录
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Design: {self.design_name}

## 迭代历史

| Iter | 策略 | 参数变化 | WNS 变化 | 面积变化 | 状态 |
|------|------|----------|----------|----------|------|
{chr(10).join(rows)}

## 关键结论

- **最优迭代**: #{self.best_iteration} (PPA Score: {self.best_score:.1f})
- **最优 WNS**: {self.best_ppa.get('wns_ns', 0):.3f}ns @ {self.best_ppa.get('freq_mhz', 0)}MHz
- **最优面积**: {self.best_ppa.get('area_um2', 0)/1000:.1f}k μm²
- **最优功耗**: {self.best_ppa.get('total_power_mw', 0):.3f}mW

## 各迭代详细分析

"""
        + "\n\n".join(
            f"### Iter {it['iteration']}: {it['strategy']['short_name']}\n"
            f"- **原因**: {it['strategy']['reason'][:100]}...\n"
            f"- **参数**: {it['strategy'].get('describe_delta', '-')}\n"
            f"- **预期效果**: {it['strategy']['expected_effect']}\n"
            f"- **实际效果**: WNS {it['before']['wns_ns']:+.3f}ns → "
            f"{it['after']['wns_ns']:+.3f}ns | "
            f"面积 {it['before']['area_um2']:.0f} → {it['after']['area_um2']:.0f}μm²\n"
            f"- **是否改善**: {'✓ 是' if it['improved'] else '✗ 否'}\n"
            for it in self.iterations
        ) + f"""

---
Report: PPA Optimization Iteration Log | {datetime.now().strftime('%Y-%m-%d %H:%M')}
"""


# ═══════════════════════════════════════════════════════════════════════════════
# 主程序
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="PPA 参数优化（读取实际结果 + 迭代记录）")
    parser.add_argument("--design", default="tinyRocket")
    parser.add_argument("--max-iter", type=int, default=6,
                        help="最大迭代次数（默认 6，对应 6 个策略）")
    parser.add_argument("--skip-run", action="store_true",
                        help="跳过运行，仅使用已有结果生成报告")
    args = parser.parse_args()

    print("=" * 65)
    print(f"  PPA 参数优化 — {args.design}")
    print(f"  策略: 读取实际后端结果，迭代调参，记录每次调整原因")
    print("=" * 65)

    # 加载基准（当前实际结果）
    state = load_actual_results(args.design)
    if not state:
        print("  [错误] 未找到实际后端结果，请先运行 make run-backend")
        return 1

    baseline = extract_ppa(state)
    baseline["score"] = ppa_score(baseline)

    print(f"\n  基准 PPA:")
    print(f"    频率: {baseline['freq_mhz']} MHz  周期: {baseline['period_ns']}ns")
    print(f"    WNS:  {baseline['wns_ns']:+.3f}ns")
    print(f"    面积: {baseline['area_um2']:,.0f} μm²")
    print(f"    功耗: {baseline['total_power_mw']:.3f} mW")
    print(f"    Skew: {baseline['skew_ns']:.3f}ns  DRC: {baseline['drc_violations']}")
    print(f"    PPA Score: {baseline['score']:.1f}")

    # 初始化历史记录器
    history = OptimizationHistory(args.design)

    # 记录初始基准为 iteration 0
    history.add_iteration(
        iter_num=0,
        strategy=OptimizationStrategy(
            name="baseline", short_name="基准",
            reason="读取当前实际后端结果作为优化起点",
            param_delta={}, expected_effect="建立基准"
        ),
        before=baseline, after=baseline
    )

    # 检查容器
    ok, _, _ = _docker_exec(ORFS_CONTAINER, ["echo", "OK"])
    if not ok:
        print("  [错误] ORFS 容器未运行")
        return 1

    current = baseline.copy()

    # 迭代优化
    strategies_to_run = STRATEGIES[:args.max_iter]
    print(f"\n  将按顺序应用 {len(strategies_to_run)} 个优化策略:")
    for s in strategies_to_run:
        print(f"    [{s.short_name}] {s.reason[:60]}...")

    for i, strategy in enumerate(strategies_to_run):
        iter_num = i + 1
        print(f"\n{'─'*65}")
        print(f"  迭代 #{iter_num}: {strategy.short_name}")
        print(f"  原因:   {strategy.reason[:100]}")
        print(f"  变化:   {strategy.describe_delta()}")
        print(f"  预期:   {strategy.expected_effect}")
        print(f"{'─'*65}")

        # 应用参数
        if not args.skip_run:
            ok_apply = apply_strategy(strategy)
            if not ok_apply:
                print(f"  [!] 参数应用失败，跳过")
                continue

            # 运行后端流程
            print(f"  → 运行后端流程...")
            after = run_full_flow()

            if "error" in after:
                print(f"  [!] 后端流程出错: {after['error']}")
                if strategy.reverse_on_fail:
                    revert_strategy(strategy)
                    print(f"  → 已回退参数变更")
                history.add_iteration(iter_num, strategy, current, current)
                continue
        else:
            # skip-run: 使用模拟值
            after = {
                "wns_ns": max(-0.1, current["wns_ns"] - 0.05),
                "area_um2": current["area_um2"] * 0.95,
                "freq_mhz": current["freq_mhz"],
                "total_power_mw": current["total_power_mw"],
                "skew_ns": current["skew_ns"],
                "drc_violations": current["drc_violations"],
                "utilization": current["utilization"],
                "density": current["density"],
                "score": ppa_score(current) + 5,
            }

        # 记录
        history.add_iteration(iter_num, strategy, current, after)
        current = after

        # 输出对比
        wns_chg = after["wns_ns"] - baseline["wns_ns"]
        area_chg = after["area_um2"] - baseline["area_um2"]
        icon = "✓" if history.iterations[-1]["improved"] else "✗"
        print(f"\n  结果 [{icon}]:")
        print(f"    WNS:   {after['wns_ns']:+.3f}ns "
              f"(变化 {wns_chg:+.3f}ns)")
        print(f"    面积:  {after['area_um2']:,.0f}μm² "
              f"(变化 {area_chg:+.0f}μm²)")
        print(f"    Score: {after['score']:.1f}")

        # 判断是否需要回退（若恶化）
        if not history.iterations[-1]["improved"] and strategy.reverse_on_fail:
            revert_strategy(strategy)
            current = baseline.copy()  # 重置为基准
            print(f"  → 效果未改善，已回退参数")

    # 保存结果
    history_file = OPT_DIR / f"{args.design}_optimization_history.json"
    history_file.write_text(json.dumps(history.to_dict(), indent=2, ensure_ascii=False))
    print(f"\n  迭代历史: {history_file}")

    # 生成报告
    report_md = history.summary_md()
    report_file = REPORTS_DIR / "ppa_optimization_report.md"
    report_file.write_text(report_md)
    print(f"  优化报告: {report_file}")

    # 汇总
    print(f"\n{'='*65}")
    print(f"  优化完成！")
    print(f"  总迭代:   {len(history.iterations) - 1} 次")
    print(f"  最优迭代: #{history.best_iteration} (Score: {history.best_score:.1f})")
    print(f"  最优 WNS: {history.best_ppa.get('wns_ns', 0):+.3f}ns")
    print(f"  最优面积: {history.best_ppa.get('area_um2', 0):,.0f}μm²")
    print(f"{'='*65}")

    return 0


if __name__ == "__main__":
    sys.exit(main())

