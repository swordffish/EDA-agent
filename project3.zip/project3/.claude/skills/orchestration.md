# 全流程编排 Skill

## 概述

定义从自然语言指令到 PPA 报告的端到端编排逻辑。

## 编排流程

```
用户自然语言指令
    ↓
需求解析 → 生成 requirement_spec.md
    ↓
Chipyard RTL 生成 (chipyard_gen.py)
    ↓
PPA 参数优化 (ppa_optimize.py) — 分阶段迭代调参
    ↓
后端全流程 (backend_flow.py)
  synthesis → floorplan → placement → cts → routing → sta
    ↓
PPA 报告生成 (ppa_report.py)
    ↓
PPT 汇报材料 (gen_ppt.py)
```

## PPA 优化策略（加分项）

| Pass | 策略 | 方向 | 关键参数 |
|------|------|------|----------|
| P0 | 基线 | 参照 | ORFS默认参数 |
| P1-area-util-high | 提高利用率 | 面积↓ | CORE_UTIL 60→70% |
| P1-area-dense | 提高密度 | 面积↓ | PLACE_DENSITY 0.75→0.78 |
| P2-timing-pad | 单元间距填充 | 时序↑ | CELL_PAD 0→2 sites |
| P2-timing-slack | 时序裕量 | 时序↑ | SETUP_SLACK_MARGIN 0→0.1ns |
| P2-timing-aggressive | 激进频率目标 | 频率↑ | PERIOD 1.2ns→1.0ns |
| P3-power-ctb | 减少时钟树缓冲 | 功耗↓ | CTS_BUF_DISTANCE 100→150μm |
| P4-balanced | 平衡策略 | 综合 | UTIL=65%, DENSITY=0.76, PAD=1 |
| P4-area-timing-equal | 面积时序均衡 | 综合 | UTIL=68%, DENSITY=0.77 |

### 核心推理逻辑

- **面积**：利用率每+10%，芯片面积减少约14%；tinyRocket(60K门)建议上限70%
- **时序**：cell_padding每+1 site，WNS改善约0.015ns，代价面积+3-5%
- **功耗**：CTB间距每+50μm，时钟树功耗减少约30%，需确保skew<0.3ns
- **裕量**：所有设计建议SETUP_SLACK≥0.05ns，为PVT波动留安全边界

## 执行命令

```bash
# 完整流程
make run-full DESIGN_NAME=tinyRocket

# 分步执行
make gen-rtl          # RTL 生成
make ppa-optimize     # PPA 参数优化（9个Pass迭代）
make run-backend      # 后端流程
make report           # PPA 报告
make gen-ppt          # PPT 生成
```

## 阶段验收标准

| 阶段 | 达标条件 | 未达标处理 |
|------|----------|------------|
| RTL 生成 | .v 文件 ≥ 5 个，无语法错误 | 修复后重试 |
| PPA 优化 | 找到 score 最高的 Pass | 调整参数范围 |
| 综合 | 门数 > 0，无 error | 诊断错误 |
| 布局规划 | 利用率 50-70% | 调整面积 |
| 放置 | 密度 < 80% | 降低密度 |
| CTS | Skew < 0.5ns | 增加缓冲器 |
| 布线 | DRC = 0 | 调整间距重布 |
| STA | WNS ≥ 0 | 时序优化 |
