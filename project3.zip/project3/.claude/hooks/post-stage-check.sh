#!/bin/bash
# Post-stage check hook - 各阶段完成后验证结果

STAGE=$1
DESIGN=$2

echo "[Post-Stage Check] Stage: $STAGE, Design: $DESIGN"

case $STAGE in
    synthesis)
        if [ -f "results/synthesis/${DESIGN}_synthesis_result.json" ]; then
            echo "[OK] Synthesis result exists"
        else
            echo "[WARN] Synthesis result not found"
        fi
        ;;
    floorplan)
        if [ -f "results/floorplan/${DESIGN}.def" ]; then
            echo "[OK] Floorplan DEF exists"
        else
            echo "[WARN] Floorplan DEF not found"
        fi
        ;;
    placement)
        if [ -f "results/placement/${DESIGN}.def" ]; then
            echo "[OK] Placement DEF exists"
        else
            echo "[WARN] Placement DEF not found"
        fi
        ;;
    cts)
        if [ -f "results/cts/${DESIGN}.def" ]; then
            echo "[OK] CTS result exists"
        else
            echo "[WARN] CTS result not found"
        fi
        ;;
    routing)
        if [ -f "results/routing/${DESIGN}.def" ]; then
            echo "[OK] Routing result exists"
        else
            echo "[WARN] Routing result not found"
        fi
        ;;
    sta)
        if [ -f "reports/timing_${DESIGN}.rpt" ]; then
            echo "[OK] STA report exists"
        else
            echo "[WARN] STA report not found"
        fi
        ;;
    *)
        echo "[INFO] No specific check for stage: $STAGE"
        ;;
esac

exit 0
