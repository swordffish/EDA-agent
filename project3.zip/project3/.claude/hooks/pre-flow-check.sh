#!/bin/bash
# Pre-flow check hook - 执行前检查必要文件和环境

echo "[Pre-Flow Check]"

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: python3 not found"
    exit 1
fi

# 检查必要的目录
for dir in design/rtl design/constraints results logs reports; do
    if [ ! -d "$dir" ]; then
        mkdir -p "$dir"
        echo "[Pre-Flow] Created directory: $dir"
    fi
done

# 检查 RTL 文件
RTL_COUNT=$(find design/rtl -name "*.v" 2>/dev/null | wc -l)
echo "[Pre-Flow] RTL files found: $RTL_COUNT"

echo "[Pre-Flow Check] Passed"
exit 0
