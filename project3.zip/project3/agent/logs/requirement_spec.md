# TinyRocket 需求规格文档
Generated: 2026-05-07 21:57:44

## 原始指令
请帮我生成一个tinyRocket处理器并完成后端全流程

## 解析后的配置

| 参数 | 值 |
|------|-----|
| 设计名称 | tinyRocket |
| ISA | RV64GC |
| 核数 | 1 |
| L1 D/I Cache | 16 KB |
| L2 Cache | 512 KB |
| 目标频率 | 833 MHz |
| 模块名 | RocketTile |

## 工具链

| 阶段 | 容器 | 工具 |
|------|------|------|
| RTL 生成 | Chipyard (ictmrc/chipyard-image) | sbt, firtool |
| 后端流程 | ORFS (openroad/orfs:latest) | Yosys, OpenROAD, OpenSTA |

## 验收标准
- [ ] RTL 成功生成，无语法错误
- [ ] 综合成功，无时序违例（目标 833 MHz）
- [ ] 布线完成，DRC = 0
- [ ] PPA 报告生成完整
