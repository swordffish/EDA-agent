"""Project 3 - TinyRocket 全流程自动化编排层"""

from .tinyrocket_flow import main

__all__ = ["main"]
