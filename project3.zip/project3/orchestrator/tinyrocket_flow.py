#!/usr/bin/env python3
"""
主编排器 - 串联 RTL 生成 + 后端流程 + 报告 + PPT
"""

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from datetime import datetime

SCRIPT_DIR = Path(__file__).parent.resolve()
PROJECT_DIR = SCRIPT_DIR.parent.resolve()
SCRIPTS_DIR = PROJECT_DIR / "scripts"
RESULTS_DIR = PROJECT_DIR / "results"
AGENT_LOGS  = PROJECT_DIR / "agent" / "logs"

AGENT_LOGS.mkdir(parents=True, exist_ok=True)


def run_step(name: str, script: str, args: list, env: str = None) -> bool:
    """运行单个步骤"""
    print(f"\n{'='*60}")
    print(f"  Step: {name}")
    print(f"{'='*60}")
    start = time.time()
    cmd = [sys.executable, str(SCRIPTS_DIR / script)] + args
    result = subprocess.run(cmd, cwd=SCRIPTS_DIR)
    elapsed = time.time() - start
    status = "✓" if result.returncode == 0 else "✗"
    print(f"\n  [{status}] {name} 完成 (耗时: {elapsed:.1f}s)")
    return result.returncode == 0


def main():
    parser = argparse.ArgumentParser(description="TinyRocket 全流程编排器")
    parser.add_argument("--design", default="tinyRocket")
    parser.add_argument("--instruction",
        default="请帮我生成一个tinyRocket处理器并完成后端全流程")
    parser.add_argument("--skip-rtl", action="store_true")
    parser.add_argument("--skip-backend", action="store_true")
    parser.add_argument("--skip-ppt", action="store_true")
    parser.add_argument("--use-builtin", action="store_true",
        help="使用 ORFS 内置 RTL，跳过 Chipyard 生成")
    args = parser.parse_args()

    design_name = args.design
    start_time = datetime.now()

    print("=" * 65)
    print(f"  TinyRocket 全流程编排器")
    print(f"  设计: {design_name}")
    print(f"  指令: {args.instruction}")
    print(f"  开始: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 65)

    steps = [
        ("RTL 生成 (Chipyard)", "chipyard_gen.py",
         ["--design", design_name, "--instruction", args.instruction],
         args.skip_rtl),
        ("后端流程 (OpenROAD)", "backend_flow.py",
         ["--design", design_name,
          "--use-builtin" if args.use_builtin else ""],
         args.skip_backend),
        ("PPA 报告", "ppa_report.py",
         ["--design", design_name, "--results-dir", str(RESULTS_DIR)],
         False),
        ("PPT 汇报", "gen_ppt.py",
         ["--design", design_name],
         args.skip_ppt),
    ]

    results = {}
    for name, script, script_args, skip in steps:
        script_args = [a for a in script_args if a]  # 过滤空字符串
        if skip:
            print(f"\n  [跳过] {name}")
            results[name] = "skipped"
            continue

        ok = run_step(name, script, script_args)
        results[name] = "completed" if ok else "failed"
        if not ok:
            print(f"\n  [!] {name} 失败，停止后续步骤")
            break

    end_time = datetime.now()
    elapsed_total = (end_time - start_time).total_seconds()

    # 保存执行摘要
    summary = {
        "design": design_name,
        "instruction": args.instruction,
        "start_time": start_time.isoformat(),
        "end_time": end_time.isoformat(),
        "elapsed_s": round(elapsed_total, 1),
        "steps": results,
        "overall": "PASS" if all(v == "completed" for v in results.values()) else "FAIL",
    }
    (AGENT_LOGS / "execution_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False)
    )

    # 打印汇总
    print(f"\n{'='*65}")
    print("  执行摘要")
    print(f"{'='*65}")
    for name, status in results.items():
        icon = {"completed": "✓", "skipped": "⊘", "failed": "✗"}.get(status, "?")
        print(f"  {icon} {name}: {status}")

    overall = "PASS ✓" if summary["overall"] == "PASS" else "FAIL ✗"
    print(f"\n  整体状态: {overall}")
    print(f"  总耗时: {elapsed_total:.1f}s")
    print(f"\n  输出文件:")
    print(f"    RTL:          design/rtl/*.v")
    print(f"    后端结果:     results/")
    print(f"    PPA 报告:    reports/ppa_report.md")
    print(f"    PPT:         ppt/{design_name}_flow.pptx")

    return 0 if summary["overall"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
