// ICache 16KB
module tinyRocket_icache #(
    parameter SIZE_KB=16
) (
    input  wire        clock, reset,
    input  wire [31:0] addr,
    input  wire        req_valid,
    output reg  [63:0] line_out, output reg line_valid,
    output wire [31:0] mem_addr, output reg mem_valid, input mem_ready,
    input  wire [63:0] mem_rdata
);
    localparam SETS = 16;
    reg [31:9] tags [0:SETS-1];
    reg        valids [0:SETS-1];
    reg [63:0] data [0:SETS-1];
    wire [$clog2(SETS)-1:0] idx = addr[8+$clog2(SETS)-1:9];
    wire hit = valids[idx] && (tags[idx]==addr[31:9]);
    always @(posedge clock) begin
        if (reset) begin line_valid<=0; mem_valid<=0; end
        else if (req_valid) begin
            if (hit) begin line_out<=data[idx]; line_valid<=1; end
            else begin mem_valid<=1;
                if (mem_ready) begin data[idx]<=mem_rdata; tags[idx]<=addr[31:9];
                    valids[idx]<=1; line_out<=mem_rdata; line_valid<=1; mem_valid<=0; end
            end
        end else begin line_valid<=0; mem_valid<=0; end
    end
    assign mem_addr = {addr[31:9], 9'd0};
endmodule
