// tinyRocket top module
// ISA: RV64GC | Cores: 1 | Freq: 833 MHz
module tinyRocket_top (
    input  wire        clock, reset,
    output wire [31:0] mem_req_addr,
    output wire [63:0] mem_resp_data,
    output reg         mem_resp_valid
);
    localparam N_CORES = 1;
    wire [31:0]      mem_addr   [0:N_CORES-1];
    wire [63:0]       mem_wdata  [0:N_CORES-1];
    wire              mem_valid  [0:N_CORES-1];
    wire              mem_ready  [0:N_CORES-1];
    wire [63:0]       mem_rdata  [0:N_CORES-1];
    wire              mem_rvalid [0:N_CORES-1];
    genvar i;
    generate for (i=0; i<N_CORES; i=i+1) begin : gen_core
        tinyRocket_core #(.CORE_ID(i), .ISA("RV64GC")) c (
            .clock(clock), .reset(reset),
            .mem_addr(mem_addr[i]), .mem_wdata(mem_wdata[i]),
            .mem_valid(mem_valid[i]), .mem_ready(mem_ready[i]),
            .mem_rdata(mem_rdata[i]), .mem_rvalid(mem_rvalid[i])
        );
    end endgenerate
    tinyRocket_tilelink #(.N_CORES(N_CORES)) tl (
        .clock(clock), .reset(reset),
        .core_addr(mem_addr[0]), .core_valid(mem_valid[0]),
        .core_ready(mem_ready[0]), .core_rdata(mem_rdata[0]),
        .core_rvalid(mem_rvalid[0]),
        .mem_req_addr(mem_req_addr), .mem_resp_data(mem_resp_data),
        .mem_resp_valid(mem_resp_valid)
    );
endmodule
