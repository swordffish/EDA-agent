// Execution Units
module tinyRocket_exe_units #(
    parameter ISA="RV64GC"
) (
    input  wire        clock, reset,
    input  wire [31:0] inst,
    input  wire [63:0] rs1_data, rs2_data,
    output reg  [63:0] result
);
    wire [6:0] op=inst[6:0]; wire [2:0] f3=inst[14:12]; wire [6:0] f7=inst[31:25];
    wire signed [63:0] s1=rs1_data, s2=rs2_data;
    always @(*) begin
        result=64'd0;
        if (op==7'b0110011 && f3==3'b000 && f7==7'b0000000) result=rs1_data+rs2_data;
        else if (op==7'b0110011 && f3==3'b000 && f7==7'b0100000) result=rs1_data-rs2_data;
        else if (op==7'b0110011 && f3==3'b010) result={63'd0, s1<s2};
        else if (op==7'b0110011 && f3==3'b111) result=rs1_data&rs2_data;
        else if (op==7'b0110011 && f3==3'b110) result=rs1_data|rs2_data;
        else if (op==7'b0110011 && f3==3'b100) result=rs1_data^rs2_data;
        else if (op==7'b0110011 && f3==3'b001) result=rs1_data<<rs2_data[5:0];
        else if (op==7'b0110011 && f3==3'b101 && f7==7'b0000000) result=rs1_data>>rs2_data[5:0];
        else if (op==7'b0110111) result={inst[31:12],12'd0};
        else if (op==7'b0000011) result=rs1_data+{52'd0,inst[31:20]};
    end
endmodule
