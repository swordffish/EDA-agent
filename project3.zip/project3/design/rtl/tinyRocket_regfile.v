// Register File 32x64
module tinyRocket_regfile #(
    parameter ISA="RV64GC"
) (
    input  wire        clock, reset,
    input  wire [4:0]  rs1, rs2, rd,
    input  wire        we, input wire [63:0] wdata,
    output reg  [63:0] rdata1, rdata2
);
    reg [63:0] rf [0:31];
    integer i;
    always @(posedge clock) begin
        if (reset) for(i=0;i<32;i++) rf[i]<=0;
        else begin
            if (we && rd!=0) rf[rd]<=wdata;
            rdata1<=rf[rs1]; rdata2<=rf[rs2];
        end
    end
endmodule
