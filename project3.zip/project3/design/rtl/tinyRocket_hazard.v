// Hazard Detection
module tinyRocket_hazard (
    input wire [4:0] ex_rd, mem_rd, wb_rd,
    input wire ex_we, mem_we, wb_we,
    input wire [4:0] if_rs1, if_rs2,
    output reg stall, flush
);
    wire ex_haz = ex_we && |ex_rd && (ex_rd==if_rs1 || ex_rd==if_rs2);
    wire mem_haz = mem_we && |mem_rd && (mem_rd==if_rs1 || mem_rd==if_rs2);
    always @* begin stall=ex_haz||mem_haz; flush=0; end
endmodule
