// Frontend
module tinyRocket_frontend #(
    parameter CORE_ID=0
) (
    input  wire        clock, reset,
    input  wire [31:0] pc,
    output reg  [31:0] inst, output reg if_valid,
    output wire [31:0] mem_addr, output reg mem_valid, input mem_ready,
    input  wire [63:0] mem_rdata
);
    wire [63:0] icache_line;
    reg  [63:0] icache_line_r;

    // ICache instantiation
    tinyRocket_icache #(.SIZE_KB(16)) icache (
        .clock(clock), .reset(reset),
        .addr({pc[31:9], 9'd0}),
        .req_valid(1'b1),
        .line_out(icache_line),
        .line_valid(if_valid),
        .mem_addr(mem_addr), .mem_valid(mem_valid),
        .mem_ready(mem_ready), .mem_rdata(mem_rdata)
    );

    // Register the icache output
    always @(posedge clock) begin
        if (reset) begin
            inst <= 32'b0;
            icache_line_r <= 64'b0;
        end else begin
            icache_line_r <= icache_line;
            inst <= icache_line[31:0];
        end
    end
endmodule
