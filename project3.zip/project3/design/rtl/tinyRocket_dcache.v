// DCache 16KB
module tinyRocket_dcache #(
    parameter SIZE_KB=16
) (
    input  wire        clock, reset,
    input  wire [31:0] addr, input wire [63:0] wdata, input wire [7:0] strb,
    input  wire        req_valid, output reg ack,
    output wire [31:0] mem_addr, output reg [63:0] mem_wdata,
    output reg  [7:0]  mem_strb, output reg mem_valid, input mem_ready,
    input  wire [63:0] mem_rdata
);
    localparam SETS = 16;
    reg [63:0] data [0:SETS-1];
    reg [31:9] tag [0:SETS-1];
    reg        valids [0:SETS-1];
    wire [$clog2(SETS)-1:0] idx = addr[8+$clog2(SETS)-1:9];
    wire hit = valids[idx] && (tag[idx]==addr[31:9]);
    always @(posedge clock) begin
        if (reset) begin ack<=0; mem_valid<=0; end
        else if (req_valid) begin
            if (hit) begin data[idx]<=wdata; ack<=1; end
            else begin mem_valid<=1; mem_wdata<=wdata; mem_strb<=strb;
                if (mem_ready) begin data[idx]<=mem_rdata; tag[idx]<=addr[31:9];
                    valids[idx]<=1; ack<=1; mem_valid<=0; end
            end
        end else ack<=0;
    end
    assign mem_addr = {addr[31:9], 9'd0};
endmodule
