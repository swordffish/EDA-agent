// Rocket Core
module tinyRocket_core #(
    parameter CORE_ID=0, parameter ISA="RV64GC"
) (
    input  wire        clock, reset,
    output wire [31:0] mem_addr,
    output wire [63:0] mem_wdata,
    output wire        mem_valid, input wire mem_ready,
    input  wire [63:0] mem_rdata, input wire mem_rvalid
);
    reg [31:0] pc = 32'h8000_0000;
    wire [31:0] inst;
    reg         if_valid;
    tinyRocket_frontend #(.CORE_ID(CORE_ID)) fe (
        .clock(clock), .reset(reset), .pc(pc),
        .inst(inst), .if_valid(if_valid),
        .mem_addr(mem_addr), .mem_valid(mem_valid),
        .mem_ready(mem_ready), .mem_rdata(mem_rdata)
    );
    tinyRocket_regfile #(.ISA(ISA)) rf (
        .clock(clock), .reset(reset),
        .rs1(inst[19:15]), .rs2(inst[24:20]), .rd(inst[11:7]),
        .we(if_valid), .wdata(64'd0), .rdata1(), .rdata2()
    );
    tinyRocket_exe_units #(.ISA(ISA)) exe (
        .clock(clock), .reset(reset), .inst(inst),
        .rs1_data(64'd0), .rs2_data(64'd0), .result()
    );
    always @(posedge clock) if (!reset && if_valid) pc <= pc + 4;
endmodule
