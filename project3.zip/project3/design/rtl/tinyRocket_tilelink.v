// TileLink Interconnect
module tinyRocket_tilelink #(
    parameter N_CORES=1, parameter L2_SIZE=512
) (
    input  wire        clock, reset,
    input  wire [31:0] core_addr,
    input  wire        core_valid,
    output wire        core_ready,
    output wire [63:0] core_rdata,
    output wire        core_rvalid,
    output wire [31:0] mem_req_addr,
    output wire [63:0] mem_resp_data,
    output wire        mem_resp_valid
);
    localparam SETS = L2_SIZE/4;
    reg [127:0] l2_data [0:SETS-1];
    reg [31:9]  l2_tag [0:SETS-1];
    reg         l2_valid [0:SETS-1];
    reg [1:0]   beat=0;
    reg [127:0] line_buf=0;
    reg         rvalid=0;
    wire [9:0]  idx = core_addr[7+:10];
    wire        l2_hit = l2_valid[idx] && (l2_tag[idx]==core_addr[31:9]);
    assign core_ready = l2_hit || 1'b1;
    assign core_rvalid = rvalid;
    assign core_rdata = line_buf[63:0];
    assign mem_req_addr = core_addr;
    assign mem_resp_data = 64'd0;
    assign mem_resp_valid = 1'b0;
    always @(posedge clock) begin
        if (reset) begin rvalid<=0; beat<=0; end
        else begin
            if (core_valid && !rvalid) begin
                if (l2_hit) begin core_rdata<=l2_data[idx][63:0]; rvalid<=1; end
            end
        end
    end
endmodule
