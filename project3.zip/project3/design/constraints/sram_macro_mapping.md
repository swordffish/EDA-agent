# SRAM Macro Mapping for tinyRocket / sky130hd
# ================================================
# Maps Chisel-generated SRAM module names to sky130hd LEF/LIB models.
# tinyRocket uses SRAM templates from Chipyard's SRAMGenerator.
# In sky130hd, these map to OpenRAM or hard-macro models.

# ── L1 I-Cache SRAM ─────────────────────────────────────────────
# Chisel module: data_arrays_0, tag_array (from ICache)
#   → sky130hd: OpenRAM 64x32 (or hard macro)

# L1 D-Cache SRAM
# Chisel module: data_arrays_0_0 (from DCache)
#   → sky130hd: OpenRAM 128x64

# ── Mapping Table ─────────────────────────────────────────────────
# | Chisel Module Name                  | sky130hd LEF/LIB                  | Size       |
# |------------------------------------|-----------------------------------|------------|
# | data_arrays_0                       | sky130_sram_1rw1r_64x1024_8.lef   | 64x1024x8  |
# | data_arrays_0_0                     | sky130_sram_1rw1r_128x512_8.lef   | 128x512x8  |
# | tag_array                           | sky130_sram_1rw1r_32x256_8.lef    | 32x256x8   |

# ── LEF/LIB paths (ORFS container) ───────────────────────────────
# LEF: /OpenROAD-flow-scripts/flow/platforms/sky130hd/lef/sky130_sram_*.lef
# LIB: /OpenROAD-flow-scripts/flow/platforms/sky130hd/lib/sky130_sram_*.lib

# ── ORFS config.mk additions ─────────────────────────────────────
# export ADDITIONAL_LEFS = $(sort $(wildcard $(PLATFORM_DIR)/lef/sky130_sram*.lef))
# export ADDITIONAL_LIBS = $(sort $(wildcard $(PLATFORM_DIR)/lib/sky130_sram*.lib))
# export MACRO_PLACEMENT = constraint.mplf

# ── constraint.mplf (Macro Placement) ──────────────────────────
# VERSION 1.0
# NAMESPACE tinyRocket
# UNITS DISTANCE MICRONS 1000
#
# # L1 I-Cache SRAM (top-left corner of core area)
# FIXED data_arrays_0    ( 1000  1000 ) N ;
# FIXED tag_array        ( 1000  3000 ) N ;
#
# # L1 D-Cache SRAM (bottom-left corner)
# FIXED data_arrays_0_0  ( 1000  5000 ) N ;
