current_design tinyRocket_top
create_clock -name clock -period 1.2 [get_ports {clock}]
set_input_delay [expr 1.2 * 0.2] -clock clock [all_inputs]
set_output_delay [expr 1.2 * 0.2] -clock clock [all_outputs]
set_clock_uncertainty 0.05 [get_clocks clock]
set_max_capacitance 0.5 [current_design]
set_max_transition 0.2 [current_design]
set_false_path -from [get_ports reset] -to [get_clocks clock]
