#!/usr/bin/env python3
"""SVG → PNG 转换器（纯 Python + PIL）"""
import re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

def c(s):
    """解析颜色"""
    if not s or s in ('none', ''): return None
    s = s.strip()
    if s.startswith('#'):
        h = s.lstrip('#')
        if len(h) == 3: h = ''.join(x*2 for x in h)
        return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
    names = {
        'black':(0,0,0),'white':(255,255,255),'red':(255,0,0),'green':(0,128,0),
        'blue':(0,0,255),'gray':(128,128,128),'grey':(128,128,128),
        'orange':(255,152,0),'yellow':(255,235,59),'purple':(106,27,154),
        'skyblue':(187,222,251),'lightgreen':(200,230,201),'lightblue':(187,222,251),
        'lightgray':(240,240,240),'lightgrey':(240,240,240),'cyan':(0,188,212),
        'darkgreen':(56,142,60),'brown':(121,85,72),'pink':(233,30,99),
    }
    return names.get(s.lower())

def p(v, scale):
    try: return max(0, float(re.sub(r'[^-\d.]', '', str(v))) * scale)
    except: return 0.0

def fv(attrs, key, default=None):
    v = attrs.get(key, '')
    if not v or v == 'none': return default
    return c(v)

def sv(attrs, key):
    v = attrs.get(key, 'none')
    if v == 'none': return None
    return c(v)

def sw(attrs):
    try: return max(1, int(p(attrs.get('stroke-width','1'), 1)))
    except: return 1

def op(attrs, base):
    try: return base * float(attrs.get('opacity','1'))
    except: return base

def parse_attrs(tag):
    attrs = {}
    for k, v in re.findall(r'([\w:.-]+)\s*=\s*["\']([^"\']*)["\']', tag):
        attrs[re.sub(r'^\w+:', '', k)] = v
    return attrs

class SVGImg:
    def __init__(self, text, scale=2.0):
        self.scale = scale
        text = text.replace('{w-30}','670').replace('{h-30}','470')
        text = text.replace('{w-40}','660').replace('{h-40}','460')
        m = re.search(r'width=["\']?(\d+)', text)
        self.W = int(m.group(1)) if m else 700
        m = re.search(r'height=["\']?(\d+)', text)
        self.H = int(m.group(1)) if m else 500
        self.elements = self._parse(text)
        self._font = self._load_font()

    def _load_font(self):
        for fp in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                   '/usr/share/fonts/TTF/DejaVuSans.ttf']:
            try: return ImageFont.truetype(fp, 10)
            except: pass
        return ImageFont.load_default()

    def _parse(self, svg):
        elements = []
        pos = 0
        n = len(svg)
        skip_tags = {'defs', 'style', 'title', 'desc'}
        while pos < n:
            if svg[pos] != '<':
                pos += 1; continue
            # 找标签头部
            m = re.match(r'<(/?)([\w:]+)\s*', svg[pos:])
            if not m:
                pos += 1; continue
            close, name = m.group(1), m.group(2)
            tag = re.sub(r'^\w+:', '', name)
            pos += m.end()

            # 解析属性
            attrs = {}
            end_char = None
            while pos < n:
                ch = svg[pos]
                if ch in '>':
                    end_char = ch; pos += 1; break
                if ch == '/':
                    pos += 1
                    if pos < n and svg[pos] == '>': end_char = '/>'; pos += 1; break
                    continue
                m2 = re.match(r'([\w:.-]+)\s*=\s*["\']([^"\']*)["\']', svg[pos:])
                if m2:
                    k = re.sub(r'^\w+:', '', m2.group(1))
                    attrs[k] = m2.group(2)
                    pos += m2.end()
                else:
                    pos += 1

            if close == '/':
                continue  # 闭合标签跳过

            if tag in skip_tags:
                # 跳过到闭合标签
                depth = 1
                while pos < n and depth > 0:
                    if svg[pos] != '<':
                        pos += 1; continue
                    m3 = re.match(r'<(/?)([\w:]+)\s*', svg[pos:])
                    if not m3: pos += 1; continue
                    tc = m3.group(1); tt = re.sub(r'^\w+:', '', m3.group(2))
                    if tc == '/':
                        if tt == tag: depth -= 1
                    elif svg[pos+m3.end():].lstrip()[0:2] != '/>':
                        if tt == tag: depth += 1
                    pos += m3.end()
                    while pos < n and svg[pos] not in '<>':
                        pos += 1
                    if pos < n and svg[pos] == '>': pos += 1
                continue

            # 内容处理
            if tag == 'text':
                end = svg.find('</text>', pos)
                if end >= 0:
                    attrs['_text'] = svg[pos:end].strip()
                    pos = end + 7
                elements.append((tag, attrs))
            elif tag == 'g':
                # 解析子元素
                depth = 1
                start = pos
                while pos < n and depth > 0:
                    if svg[pos] != '<':
                        pos += 1; continue
                    m3 = re.match(r'<(/?)([\w:]+)\s*', svg[pos:])
                    if not m3: pos += 1; continue
                    tc = m3.group(1); tt = re.sub(r'^\w+:', '', m3.group(2))
                    pos += m3.end()
                    while pos < n and svg[pos] not in '>/':
                        pos += 1
                    if pos < n and svg[pos] == '/':
                        pos += 1
                    if pos < n and svg[pos] == '>':
                        pos += 1
                        if tc == '/':
                            if tt == tag: depth -= 1
                        else:
                            if tt == tag: depth += 1
                    elif pos < n and svg[pos] == '<' and tc != '/':
                        if tt in ('rect','circle','line','path','text','g'):
                            if tc != '/': depth += 1
                children = self._parse(svg[start:pos])
                attrs['_children'] = children
                elements.append((tag, attrs))
            else:
                elements.append((tag, attrs))

        return elements

    def render(self):
        W, H = int(self.W*self.scale), int(self.H*self.scale)
        self.img = Image.new('RGB', (W, H), (248, 249, 250))
        self.draw = ImageDraw.Draw(self.img)
        self._draw(self.elements, 0, 0, 1.0)
        return self.img

    def _draw(self, elements, tx, ty, opacity):
        for tag, attrs in elements:
            if tag == 'rect':
                self._rect(attrs, tx, ty, opacity)
            elif tag == 'circle':
                self._circle(attrs, tx, ty, opacity)
            elif tag == 'line':
                self._line(attrs, tx, ty, opacity)
            elif tag == 'path':
                self._path(attrs, tx, ty, opacity)
            elif tag == 'text':
                self._text(attrs, tx, ty, opacity)
            elif tag == 'g':
                ntx, nty = self._tx(attrs.get('transform', ''), tx, ty)
                self._draw(attrs.get('_children', []), ntx, nty, opacity)

    def _tx(self, s, tx, ty):
        if not s: return tx, ty
        m = re.search(r'translate\(\s*([\d.-]+)(?:\s*[, ]+([\d.-]+))?\s*\)', s)
        if m: return tx+float(m.group(1)), ty+float(m.group(2) or 0)
        return tx, ty

    def _rect(self, a, tx, ty, opacity):
        x = p(a.get('x',0), self.scale)+tx
        y = p(a.get('y',0), self.scale)+ty
        w = p(a.get('width',0), self.scale)
        h = p(a.get('height',0), self.scale)
        if w<=0 or h<=0: return
        r = p(a.get('rx',0), self.scale)
        opacity = op(a, opacity)
        fill = fv(a, 'fill'); stroke = sv(a, 'stroke')
        self.draw.rounded_rectangle([x,y,x+w,y+h], radius=r,
                                     fill=fill, outline=stroke, width=sw(a))

    def _circle(self, a, tx, ty, opacity):
        cx = p(a.get('cx',0), self.scale)+tx
        cy = p(a.get('cy',0), self.scale)+ty
        r = p(a.get('r',0), self.scale)
        if r<=0: return
        opacity = op(a, opacity)
        fill = fv(a, 'fill'); stroke = sv(a, 'stroke')
        self.draw.ellipse([cx-r,cy-r,cx+r,cy+r], fill=fill, outline=stroke, width=sw(a))

    def _line(self, a, tx, ty, opacity):
        x1 = p(a.get('x1',0), self.scale)+tx
        y1 = p(a.get('y1',0), self.scale)+ty
        x2 = p(a.get('x2',0), self.scale)+tx
        y2 = p(a.get('y2',0), self.scale)+ty
        stroke = sv(a, 'stroke')
        if not stroke: return
        self.draw.line([x1,y1,x2,y2], fill=stroke, width=sw(a))

    def _path(self, a, tx, ty, opacity):
        d = a.get('d','').strip()
        if not d: return
        stroke = sv(a, 'stroke')
        if not stroke: return
        sw_v = sw(a)

        tokens = re.findall(r'[MmLlQqCcZz]|[-+]?[\d.]+', d)
        i = 0
        px_c, py_c = tx, ty
        sx, sy = tx, ty

        def pt(nx, ny): return (p(nx,self.scale)+tx, p(ny,self.scale)+ty)
        def rpt(nx, ny): return (p(nx,self.scale)+px_c, p(ny,self.scale)+py_c)

        while i < len(tokens):
            cmd = tokens[i]; i += 1
            if cmd in 'Zz':
                px_c, py_c = sx, sy; continue
            nums = []
            while i < len(tokens) and not re.match(r'[A-Za-z]', tokens[i]):
                try: nums.append(float(tokens[i])); i += 1
                except: break

            if cmd == 'M':
                px_c, py_c = pt(nums[0], nums[1]); sx, sy = px_c, py_c
                for j in range(2, len(nums)-1, 2):
                    px_c, py_c = pt(nums[j], nums[j+1])
            elif cmd == 'L':
                for j in range(0, len(nums)-1, 2):
                    nx, ny = pt(nums[j], nums[j+1])
                    self.draw.line([px_c,py_c,nx,ny], fill=stroke, width=sw_v)
                    px_c, py_c = nx, ny
            elif cmd == 'Q':
                for j in range(0, len(nums)-3, 4):
                    x1,y1 = rpt(nums[j], nums[j+1])
                    ex,ey = pt(nums[j+2], nums[j+3])
                    for t in (0.33, 0.67):
                        bx = int((1-t)*(1-t)*px_c + 2*(1-t)*t*x1 + t*t*ex)
                        by = int((1-t)*(1-t)*py_c + 2*(1-t)*t*y1 + t*t*ey)
                        self.draw.line([px_c,py_c,bx,by], fill=stroke, width=sw_v)
                        px_c, py_c = bx, by
                    self.draw.line([px_c,py_c,ex,ey], fill=stroke, width=sw_v)
                    px_c, py_c = ex, ey
            elif cmd == 'm':
                if nums:
                    px_c += p(nums[0],self.scale); py_c += p(nums[1],self.scale)
                    sx, sy = px_c, py_c
                    for j in range(2, len(nums)-1, 2):
                        px_c += p(nums[j],self.scale); py_c += p(nums[j+1],self.scale)
            elif cmd == 'l':
                for j in range(0, len(nums)-1, 2):
                    nx = px_c + p(nums[j],self.scale); ny = py_c + p(nums[j+1],self.scale)
                    self.draw.line([px_c,py_c,nx,ny], fill=stroke, width=sw_v)
                    px_c, py_c = nx, ny

    def _text(self, a, tx, ty, opacity):
        text = a.get('_text','')
        if not text: return
        x = p(a.get('x',0), self.scale)+tx
        y = p(a.get('y',0), self.scale)+ty
        fill = fv(a, 'fill', (0,0,0))
        try: size = max(6, int(p(a.get('font-size','10'), 1.0)))
        except: size = 10
        anchor = a.get('text-anchor','start')
        draw = ImageDraw.Draw(self.img)
        font = self._font
        for fp, sz in [
            ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', size),
        ]:
            try: font = ImageFont.truetype(fp, sz); break
            except: pass
        if anchor == 'middle':
            bb = draw.textbbox((0,0), text, font=font); x -= (bb[2]-bb[0])/2
        elif anchor == 'end':
            bb = draw.textbbox((0,0), text, font=font); x -= bb[2]-bb[0]
        draw.text((x, y-size*0.75), text, font=font, fill=fill)


def svg2png(src: Path, dst: Path, scale=2.0):
    text = src.read_text(encoding='utf-8')
    img = SVGImg(text, scale=scale).render()
    img.save(str(dst))
    print(f"  {dst}  ({img.width}×{img.height})")

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('svg', type=Path)
    ap.add_argument('png', type=Path)
    ap.add_argument('--scale', type=float, default=2.0)
    args = ap.parse_args()
    svg2png(args.svg, args.png, args.scale)
