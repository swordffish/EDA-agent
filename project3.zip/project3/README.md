# TinyRocket 全流程自动化 — Project 3

串联 Project 1 (RTL 生成) + Project 2 (后端流程)，实现从自然语言指令到 PPA 报告的端到端自动化。

## 快速开始

```bash
cd /home/ahema/project/project3

# 一键运行完整流程
make run-full DESIGN_NAME=tinyRocket

# 或分步运行
make gen-rtl          # Step 1: 生成 RTL
make run-backend      # Step 2: 后端全流程
make gen-ppt          # Step 3: 生成 PPT

# 查看结果
make status           # 查看流程状态
make view-layout      # 查看版图
cat reports/ppa_report.md  # 查看 PPA 报告
```

## 架构

```
自然语言指令 → 需求解析 → Chipyard RTL → OpenROAD 后端 → PPA 报告 → PPT
```

## 项目结构

```
project3/
├── CLAUDE.md                  # 项目说明
├── Makefile                   # 统一入口
├── orchestrator/
│   └── tinyrocket_flow.py     # 主编排脚本
├── scripts/
│   ├── chipyard_gen.py        # RTL 生成脚本
│   ├── backend_flow.py        # 后端流程脚本
│   ├── ppa_report.py          # PPA 报告生成
│   └── gen_ppt.py            # PPT 生成
├── design/
│   ├── rtl/                  # 生成的 RTL
│   └── constraints/          # SDC 约束文件
└── results/                  # 各阶段结果
```

## 技术栈

| 阶段 | 工具 |
|------|------|
| RTL 生成 | Chipyard / sbt / firtool / Verilator |
| 综合 | Yosys |
| 后端 | OpenROAD |
| 时序分析 | OpenSTA |
| PPT 生成 | python-pptx |

## 依赖

```bash
pip install python-pptx
```
